import type { Metadata } from "next"
import { PlatformPage } from "@/components/PlatformPage"
export const metadata: Metadata = { title: "Trading Dashboard" }
export default function DashboardPage() { return <PlatformPage view="dashboard"/> }
