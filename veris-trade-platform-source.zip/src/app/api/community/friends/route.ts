import { getCurrentProfile, isValidId, jsonError } from "@/lib/auth-profile"
import { pool } from "@/lib/db"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

export async function GET() {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to view your network.", 401)
  try {
    const result = await pool.query(
      `SELECT r."id", r."status", r."createdAt", r."fromUserId", r."toUserId",
        f."username" AS "fromUsername", t."username" AS "toUsername"
       FROM "FriendRequest" r JOIN "User" f ON f."id" = r."fromUserId" JOIN "User" t ON t."id" = r."toUserId"
       WHERE r."fromUserId" = $1 OR r."toUserId" = $1 ORDER BY r."createdAt" DESC LIMIT 100`, [profile.id],
    )
    return Response.json({ requests: result.rows })
  } catch { return jsonError("Your network is temporarily unavailable.", 503) }
}

export async function POST(request: Request) {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to send a connection request.", 401)
  let body: unknown
  try { body = await request.json() } catch { return jsonError("Request body must be valid JSON.") }
  const username = typeof body === "object" && body !== null && "username" in body && typeof body.username === "string" ? body.username.trim() : ""
  if (!/^[A-Za-z0-9_]{2,30}$/.test(username)) return jsonError("Enter a valid username.")
  try {
    const target = await pool.query(`SELECT "id" FROM "User" WHERE lower("username") = lower($1)`, [username])
    if (!target.rowCount) return jsonError("No member was found with that username.", 404)
    if (target.rows[0].id === profile.id) return jsonError("You cannot connect with yourself.")
    const requestRow = await pool.query(
      `INSERT INTO "FriendRequest" ("id", "fromUserId", "toUserId") VALUES ($1, $2, $3)
       ON CONFLICT ("fromUserId", "toUserId") DO UPDATE SET "status" = CASE WHEN "FriendRequest"."status" = 'DECLINED' THEN 'PENDING' ELSE "FriendRequest"."status" END
       RETURNING "id", "status"`, [crypto.randomUUID(), profile.id, target.rows[0].id],
    )
    return Response.json({ request: requestRow.rows[0] }, { status: 201 })
  } catch { return jsonError("Could not send the connection request.", 503) }
}

export async function PATCH(request: Request) {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to manage connection requests.", 401)
  let body: unknown
  try { body = await request.json() } catch { return jsonError("Request body must be valid JSON.") }
  const value = body as { requestId?: unknown; action?: unknown }
  if (!isValidId(value.requestId) || !["accept", "decline"].includes(String(value.action))) return jsonError("Invalid request update.")
  const status = value.action === "accept" ? "ACCEPTED" : "DECLINED"
  try {
    const result = await pool.query(
      `UPDATE "FriendRequest" SET "status" = $1 WHERE "id" = $2 AND "toUserId" = $3 AND "status" = 'PENDING' RETURNING "id", "status"`,
      [status, value.requestId, profile.id],
    )
    if (!result.rowCount) return jsonError("This request is unavailable.", 404)
    return Response.json({ request: result.rows[0] })
  } catch { return jsonError("Could not update the request.", 503) }
}
