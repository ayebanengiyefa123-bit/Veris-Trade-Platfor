import { NextResponse } from "next/server"
import { randomUUID } from "node:crypto"

const MIN_DEPOSIT = 100
const MAX_DEPOSIT = 25_000_000
const OFFERING_TARGET = 25_000_000
const BACKER_POOL_CAP = 0.4
const TOKENS_PER_DOLLAR = 10

export async function POST(request: Request) {
  let body: unknown
  try { body = await request.json() } catch { return NextResponse.json({ error: "Request body must be valid JSON." }, { status: 400 }) }
  const amount = typeof body === "object" && body !== null && "amount" in body ? Number((body as { amount: unknown }).amount) : NaN
  if (!Number.isFinite(amount) || amount < MIN_DEPOSIT || amount > MAX_DEPOSIT) {
    return NextResponse.json({ error: `Amount must be between $${MIN_DEPOSIT} and $${MAX_DEPOSIT.toLocaleString()}.` }, { status: 400 })
  }
  const equityPercent = Math.min((amount / OFFERING_TARGET) * BACKER_POOL_CAP * 100, BACKER_POOL_CAP * 100)
  return NextResponse.json({
    quoteId: `VQ-${randomUUID().slice(0, 8).toUpperCase()}`,
    status: "INDICATIVE_QUOTE",
    amountUsd: amount,
    tokensMintedEstimate: amount * TOKENS_PER_DOLLAR,
    equityPercentEstimate: Number(equityPercent.toFixed(8)),
    backerPoolCapPercent: 40,
    offeringTargetUsd: OFFERING_TARGET,
    createdAt: new Date().toISOString(),
    disclaimer: "Illustrative quote only. No funds received, tokens minted, equity issued, or investment recorded.",
  }, { status: 200, headers: { "Cache-Control": "no-store" } })
}
