import { verifyMessage, isAddress } from "viem"
import { getCurrentProfile, jsonError } from "@/lib/auth-profile"
import { pool } from "@/lib/db"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

export async function GET(request: Request) {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to link a wallet.", 401)
  const address = new URL(request.url).searchParams.get("address")
  if (!address || !isAddress(address)) return jsonError("Provide a valid EVM wallet address.")
  const nonce = crypto.randomUUID().replaceAll("-", "")
  const origin = new URL(request.url).origin
  const message = `${origin} requests a signature to verify wallet ownership.\n\nAccount: ${profile.id}\nWallet: ${address}\nNonce: ${nonce}\nIssued: ${new Date().toISOString()}\n\nThis signature does not authorize a transaction or transfer.`
  try {
    await pool.query(`DELETE FROM "WalletChallenge" WHERE "userId" = $1 AND "expiresAt" < now()`, [profile.id])
    await pool.query(`INSERT INTO "WalletChallenge" ("id", "userId", "address", "nonce", "message", "expiresAt") VALUES ($1, $2, $3, $4, $5, now() + interval '5 minutes')`, [crypto.randomUUID(), profile.id, address, nonce, message])
    return Response.json({ message, nonce, expiresInSeconds: 300 }, { headers: { "Cache-Control": "no-store" } })
  } catch { return jsonError("Could not create a wallet challenge.", 503) }
}

export async function POST(request: Request) {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to link a wallet.", 401)
  let body: unknown
  try { body = await request.json() } catch { return jsonError("Request body must be valid JSON.") }
  const value = body as { address?: unknown; nonce?: unknown; signature?: unknown; provider?: unknown }
  if (typeof value.address !== "string" || !isAddress(value.address) || typeof value.nonce !== "string" || typeof value.signature !== "string" || value.signature.length > 1024) return jsonError("Wallet verification details are invalid.")
  const client = await pool.connect()
  try {
    await client.query("BEGIN")
    const challenge = await client.query(`SELECT "message" FROM "WalletChallenge" WHERE "userId" = $1 AND "address" = $2 AND "nonce" = $3 AND "expiresAt" > now() FOR UPDATE`, [profile.id, value.address, value.nonce])
    if (!challenge.rowCount) { await client.query("ROLLBACK"); return jsonError("The wallet challenge expired or was already used.", 400) }
    const verified = await verifyMessage({ address: value.address as `0x${string}`, message: challenge.rows[0].message, signature: value.signature as `0x${string}` })
    if (!verified) { await client.query("ROLLBACK"); return jsonError("Wallet signature verification failed.", 400) }
    const provider = ["MetaMask", "Coinbase Wallet", "Other EVM"].includes(String(value.provider)) ? String(value.provider) : "Other EVM"
    const inserted = await client.query(`INSERT INTO "WalletConnection" ("id", "userId", "address", "provider") VALUES ($1, $2, $3, $4) ON CONFLICT ("address") DO UPDATE SET "provider" = EXCLUDED."provider" WHERE "WalletConnection"."userId" = EXCLUDED."userId" RETURNING "id", "address", "provider", "status"`, [crypto.randomUUID(), profile.id, value.address, provider])
    if (!inserted.rowCount) { await client.query("ROLLBACK"); return jsonError("This wallet is already linked to another account.", 409) }
    await client.query(`UPDATE "User" SET "walletAddress" = $1 WHERE "id" = $2`, [value.address, profile.id])
    await client.query(`DELETE FROM "WalletChallenge" WHERE "userId" = $1 AND "nonce" = $2`, [profile.id, value.nonce])
    await client.query("COMMIT")
    return Response.json({ wallet: inserted.rows[0], notice: "Wallet ownership verified. No funds were transferred." }, { status: 201 })
  } catch {
    await client.query("ROLLBACK")
    return jsonError("Could not verify this wallet.", 503)
  } finally { client.release() }
}
