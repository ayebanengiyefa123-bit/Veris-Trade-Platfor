import { getCurrentProfile, isValidId, jsonError } from "@/lib/auth-profile"
import { pool } from "@/lib/db"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

export async function GET(request: Request) {
  const postId = new URL(request.url).searchParams.get("postId")
  if (!isValidId(postId)) return jsonError("Choose a valid post.")
  try {
    const result = await pool.query(
      `SELECT c."id", c."content", c."createdAt", u."username",
        (SELECT count(*)::int FROM "CommentLike" l WHERE l."commentId" = c."id") AS "likes"
       FROM "PostComment" c JOIN "User" u ON u."id" = c."userId"
       WHERE c."postId" = $1 ORDER BY c."createdAt" ASC LIMIT 100`, [postId],
    )
    return Response.json({ comments: result.rows })
  } catch {
    return jsonError("Comments are temporarily unavailable.", 503)
  }
}

export async function POST(request: Request) {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to join the conversation.", 401)
  let body: unknown
  try { body = await request.json() } catch { return jsonError("Request body must be valid JSON.") }
  if (typeof body !== "object" || body === null) return jsonError("Invalid request.")
  const value = body as { action?: unknown; commentId?: unknown; postId?: unknown; content?: unknown }

  if (value.action === "like") {
    if (!isValidId(value.commentId)) return jsonError("Choose a valid comment.")
    const client = await pool.connect()
    try {
      await client.query("BEGIN")
      const found = await client.query(`SELECT "id" FROM "PostComment" WHERE "id" = $1`, [value.commentId])
      if (!found.rowCount) { await client.query("ROLLBACK"); return jsonError("Comment not found.", 404) }
      const current = await client.query(`SELECT "id" FROM "CommentLike" WHERE "commentId" = $1 AND "userId" = $2`, [value.commentId, profile.id])
      if (current.rowCount) await client.query(`DELETE FROM "CommentLike" WHERE "commentId" = $1 AND "userId" = $2`, [value.commentId, profile.id])
      else await client.query(`INSERT INTO "CommentLike" ("id", "commentId", "userId") VALUES ($1, $2, $3)`, [crypto.randomUUID(), value.commentId, profile.id])
      await client.query(
        `WITH totals AS (SELECT sum(GREATEST(u."tokenBalance", 0)) AS holdings FROM "CommentLike" l JOIN "User" u ON u."id" = l."userId" WHERE l."commentId" = $1)
         UPDATE "CommentLike" l SET "holdingWeight" = CASE WHEN totals.holdings > 0 THEN (GREATEST(u."tokenBalance", 0) / totals.holdings)::numeric(12,8) ELSE 0 END
         FROM "User" u, totals WHERE l."commentId" = $1 AND u."id" = l."userId"`, [value.commentId],
      )
      const likes = await client.query(`SELECT count(*)::int AS count FROM "CommentLike" WHERE "commentId" = $1`, [value.commentId])
      await client.query("COMMIT")
      return Response.json({ likes: likes.rows[0].count, reward: "Holding-weighted share recorded for review; no tokens are issued or transferred." })
    } catch {
      await client.query("ROLLBACK")
      return jsonError("Could not update this comment.", 503)
    } finally { client.release() }
  }

  if (!isValidId(value.postId) || typeof value.content !== "string") return jsonError("Add a comment to a valid post.")
  const content = value.content.trim()
  if (!content || content.length > 1000) return jsonError("Comment must contain between 1 and 1,000 characters.")
  try {
    const result = await pool.query(
      `INSERT INTO "PostComment" ("id", "postId", "userId", "content")
       SELECT $1, p."id", $3, $4 FROM "Post" p WHERE p."id" = $2
       RETURNING "id", "postId", "content", "createdAt"`,
      [crypto.randomUUID(), value.postId, profile.id, content],
    )
    if (!result.rowCount) return jsonError("Post not found.", 404)
    return Response.json({ comment: { ...result.rows[0], username: profile.username, likes: 0 } }, { status: 201 })
  } catch {
    return jsonError("Could not save your comment.", 503)
  }
}
