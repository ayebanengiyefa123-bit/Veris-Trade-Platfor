import { clerkMiddleware } from "@clerk/nextjs/server"
import { NextResponse } from "next/server"

const clerkConfigured = Boolean(process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY && process.env.CLERK_SECRET_KEY)

const handler = clerkConfigured
  ? clerkMiddleware(async (auth, request) => {
      const protectedPath = /^\/(dashboard|community|academy|loans)(\/|$)/.test(request.nextUrl.pathname)
      if (protectedPath) await auth.protect()
    })
  : () => NextResponse.next()

export default handler

export const config = {
  matcher: [
    "/((?!_next|[^?]*\\.(?:html?|css|js(?!on)|jpe?g|webp|png|gif|svg|ttf|woff2?|ico|csv|docx?|xlsx?|zip|webmanifest)).*)",
    "/(api|trpc)(.*)",
  ],
}
