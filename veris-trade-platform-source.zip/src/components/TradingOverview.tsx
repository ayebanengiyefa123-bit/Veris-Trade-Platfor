"use client"

import useSWR from "swr"
import { ArrowDownLeft, ArrowUpRight, ShieldCheck, Wallet } from "lucide-react"

type ProfileData = {
  profile: { username: string; balance: string; tokenBalance: string }
  compliance: { status: string } | null
  wallets: Array<{ address: string; provider: string; status: string }>
  ledger: Array<{ id: string; entryType: string; amount: string; asset: string; status: string; description: string; createdAt: string }>
}
const fetcher = async (url: string): Promise<ProfileData> => {
  const response = await fetch(url, { cache: "no-store" })
  const data = await response.json()
  if (!response.ok) throw new Error(data.error || "Could not load account details.")
  return data
}
const money = (value: string) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 2 }).format(Number(value || 0))

export function TradingOverview() {
  const { data, error } = useSWR<ProfileData>("/api/profile", fetcher)
  return <div className="mx-auto max-w-[1320px] px-5 pt-9 md:px-8"><div className="mb-6 flex flex-wrap items-end justify-between gap-4"><div><p className="text-[10px] uppercase tracking-[.2em] text-cyan-200">Portfolio overview</p><h1 className="mt-2 text-3xl font-medium">Welcome, {data?.profile.username ?? "investor"}</h1><p className="mt-2 text-sm text-slate-500">Balances below reflect the Veris application ledger, not a bank or blockchain balance.</p></div><span className="inline-flex items-center gap-2 rounded-full border border-amber-200/10 bg-amber-200/[.04] px-3 py-1.5 text-[10px] text-amber-100/80"><ShieldCheck size={13}/> Account controls enabled</span></div>
    {error && <p role="status" className="mb-4 text-xs text-rose-300">{error.message}</p>}
    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4"><Metric label="Recorded account balance" value={data ? money(data.profile.balance) : "—"} note="App ledger only" icon={Wallet}/><Metric label="NEX ledger balance" value={data ? `${Number(data.profile.tokenBalance).toLocaleString(undefined, { maximumFractionDigits: 6 })} NEX` : "—"} note="No tokens issued here" icon={ArrowUpRight}/><Metric label="Verified wallets" value={data ? String(data.wallets.length) : "—"} note="Proof-of-control signatures" icon={ArrowDownLeft}/><Metric label="Compliance" value={data?.compliance?.status?.replaceAll("_", " ") ?? "NOT STARTED"} note="No KYC provider configured" icon={ShieldCheck}/></div>
    <section className="glass mt-5 rounded-2xl p-5" aria-labelledby="ledger-title"><div className="flex flex-wrap items-center justify-between gap-3"><div><p className="text-[10px] uppercase tracking-[.18em] text-cyan-200">Private account activity</p><h2 id="ledger-title" className="mt-1 text-sm font-semibold">Transaction and reward ledger</h2></div><span className="text-[10px] text-slate-600">Visible only to you</span></div>{!data?.ledger.length && <div className="mt-4 rounded-xl border border-dashed border-white/10 p-5 text-center text-xs text-slate-500">No completed transactions or token rewards have been recorded. Pending portfolio requests appear below.</div>}<div className="mt-3 flex flex-col">{data?.ledger.map((item) => <div key={item.id} className="flex flex-wrap items-center justify-between gap-3 border-t border-white/[.05] py-3"><div><p className="text-xs text-slate-300">{item.description}</p><p className="mt-1 text-[10px] text-slate-600">{item.entryType} · {new Date(item.createdAt).toLocaleString()}</p></div><div className="text-right"><p className="mono text-xs text-slate-200">{Number(item.amount).toLocaleString()} {item.asset}</p><p className="mt-1 text-[9px] text-amber-200">{item.status.replaceAll("_", " ")}</p></div></div>)}</div><p className="mt-3 text-[10px] leading-5 text-slate-600">Application records do not constitute settlement, custody, or proof of on-chain issuance.</p></section>
  </div>
}

function Metric({ label, value, note, icon: Icon }: { label: string; value: string; note: string; icon: typeof Wallet }) {
  return <article className="glass rounded-xl p-4"><div className="flex items-start justify-between gap-3"><div><p className="text-[10px] text-slate-500">{label}</p><p className="mono mt-2 text-xl font-medium text-slate-100">{value}</p><p className="mt-1 text-[10px] text-slate-600">{note}</p></div><span className="grid size-9 place-items-center rounded-lg bg-cyan-300/[.07] text-cyan-200"><Icon size={16}/></span></div></article>
}
