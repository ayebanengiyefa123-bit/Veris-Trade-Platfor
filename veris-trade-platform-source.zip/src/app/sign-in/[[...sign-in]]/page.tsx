import { SignIn } from "@clerk/nextjs"
import { Navbar } from "@/components/Navbar"

export default function SignInPage() {
  if (!process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY) return <><Navbar/><main className="mx-auto max-w-xl px-5 py-20 text-sm text-slate-300">Clerk is not configured for this environment.</main></>
  return <><Navbar/><main className="grid min-h-[calc(100vh-73px)] place-items-center px-5 py-10"><SignIn forceRedirectUrl="/dashboard"/></main></>
}
