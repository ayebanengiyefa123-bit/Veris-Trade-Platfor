import { getCurrentProfile, jsonError } from "@/lib/auth-profile"
import { pool } from "@/lib/db"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

export async function GET() {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to view the trade room.", 401)
  try {
    const result = await pool.query(`SELECT t."id", t."title", t."setup", t."entryLogic", t."exitLogic", t."riskParams", t."rationale", t."publishedAt", u."username" AS "author" FROM "TradeAnalysis" t JOIN "User" u ON u."id" = t."authorId" ORDER BY t."publishedAt" DESC LIMIT 30`)
    return Response.json({ analyses: result.rows })
  } catch { return jsonError("Trade analysis is temporarily unavailable.", 503) }
}

export async function POST(request: Request) {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to publish analysis.", 401)
  if (!["ADMIN", "LECTURER", "ANALYST"].includes(profile.role)) return jsonError("Only approved analysts can publish trade analysis.", 403)
  let body: unknown
  try { body = await request.json() } catch { return jsonError("Request body must be valid JSON.") }
  const value = body as Record<string, unknown>
  const fields = ["title", "setup", "entryLogic", "exitLogic", "riskParams", "rationale"] as const
  const clean = Object.fromEntries(fields.map((key) => [key, typeof value?.[key] === "string" ? value[key].trim() : ""])) as Record<(typeof fields)[number], string>
  if (fields.some((key) => !clean[key] || clean[key].length > 2000)) return jsonError("Complete each analysis section (up to 2,000 characters each).")
  try {
    const result = await pool.query(`INSERT INTO "TradeAnalysis" ("id", "authorId", "title", "setup", "entryLogic", "exitLogic", "riskParams", "rationale") VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING "id", "title", "setup", "entryLogic", "exitLogic", "riskParams", "rationale", "publishedAt"`, [crypto.randomUUID(), profile.id, clean.title, clean.setup, clean.entryLogic, clean.exitLogic, clean.riskParams, clean.rationale])
    return Response.json({ analysis: { ...result.rows[0], author: profile.username } }, { status: 201 })
  } catch { return jsonError("Could not publish this analysis.", 503) }
}
