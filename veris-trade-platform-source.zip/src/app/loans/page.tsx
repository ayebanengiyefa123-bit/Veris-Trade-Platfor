import type { Metadata } from "next"
import { Navbar } from "@/components/Navbar"
import { LoansHub } from "@/components/LoansHub"

export const metadata: Metadata = {
  title: "Credit access",
  description: "Request a private review for auto financing, mortgages, and short-term credit access.",
  robots: { index: false, follow: false },
}

export default function LoansPage() {
  return <div className="min-h-screen"><Navbar/><main><LoansHub/></main></div>
}
