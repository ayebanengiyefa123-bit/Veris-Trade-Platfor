import { getCurrentProfile, jsonError, isValidId } from "@/lib/auth-profile"
import { pool } from "@/lib/db"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

export async function GET() {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to view learning progress.", 401)
  try {
    const result = await pool.query(`SELECT "lessonId", "completedAt" FROM "LessonProgress" WHERE "userId" = $1 ORDER BY "completedAt" DESC`, [profile.id])
    return Response.json({ completed: result.rows })
  } catch { return jsonError("Learning progress is temporarily unavailable.", 503) }
}

export async function POST(request: Request) {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to record lesson progress.", 401)
  let body: unknown
  try { body = await request.json() } catch { return jsonError("Request body must be valid JSON.") }
  const lessonId = typeof body === "object" && body !== null && "lessonId" in body ? body.lessonId : null
  if (!isValidId(lessonId)) return jsonError("Choose a valid lesson.")
  try {
    const result = await pool.query(`INSERT INTO "LessonProgress" ("userId", "lessonId") SELECT $1, l."id" FROM "Lesson" l WHERE l."id" = $2 AND l."published" = true ON CONFLICT ("userId", "lessonId") DO NOTHING RETURNING "lessonId", "completedAt"`, [profile.id, lessonId])
    if (!result.rowCount) {
      const existing = await pool.query(`SELECT "lessonId", "completedAt" FROM "LessonProgress" WHERE "userId" = $1 AND "lessonId" = $2`, [profile.id, lessonId])
      if (!existing.rowCount) return jsonError("Published lesson not found.", 404)
      return Response.json({ progress: existing.rows[0] })
    }
    return Response.json({ progress: result.rows[0] }, { status: 201 })
  } catch { return jsonError("Could not record this lesson.", 503) }
}
