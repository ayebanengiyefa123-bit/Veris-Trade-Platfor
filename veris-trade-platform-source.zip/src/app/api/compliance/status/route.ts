import { getCurrentProfile, jsonError } from "@/lib/auth-profile"
import { pool } from "@/lib/db"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

export async function GET() {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to view compliance status.", 401)
  try {
    const result = await pool.query(`SELECT "countryCode", "jurisdiction", "status", "updatedAt" FROM "UserCompliance" WHERE "userId" = $1`, [profile.id])
    return Response.json({ compliance: result.rows[0] ?? { countryCode: null, jurisdiction: null, status: "NOT_STARTED" } })
  } catch { return jsonError("Compliance status is temporarily unavailable.", 503) }
}

export async function POST(request: Request) {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to update compliance details.", 401)
  let body: unknown
  try { body = await request.json() } catch { return jsonError("Request body must be valid JSON.") }
  const countryCode = typeof body === "object" && body !== null && "countryCode" in body && typeof body.countryCode === "string" ? body.countryCode.toUpperCase() : ""
  if (!/^[A-Z]{2}$/.test(countryCode)) return jsonError("Select a valid two-letter country or jurisdiction code.")
  try {
    const result = await pool.query(
      `INSERT INTO "UserCompliance" ("id", "userId", "countryCode", "jurisdiction", "status", "updatedAt")
       VALUES ($1, $2, $3, $4, 'PENDING_REVIEW', now())
       ON CONFLICT ("userId") DO UPDATE SET "countryCode" = EXCLUDED."countryCode", "jurisdiction" = EXCLUDED."jurisdiction", "status" = 'PENDING_REVIEW', "updatedAt" = now()
       RETURNING "countryCode", "jurisdiction", "status", "updatedAt"`, [crypto.randomUUID(), profile.id, countryCode, countryCode],
    )
    return Response.json({ compliance: result.rows[0], notice: "Jurisdiction recorded. Identity verification requires a configured KYC provider; this status is not a verification result." }, { status: 201 })
  } catch { return jsonError("Could not update compliance details.", 503) }
}
