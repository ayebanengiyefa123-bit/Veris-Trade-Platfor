import { getCurrentProfile, jsonError } from "@/lib/auth-profile"
import { pool } from "@/lib/db"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

export async function GET() {
  try {
    const result = await pool.query(`SELECT c."id", c."title", c."description", c."tutorName", c."createdAt", u."username" AS "author", count(l."id")::int AS "lessonCount" FROM "Course" c JOIN "User" u ON u."id" = c."authorId" LEFT JOIN "Lesson" l ON l."courseId" = c."id" AND l."published" = true GROUP BY c."id", u."username" ORDER BY c."createdAt" DESC LIMIT 50`)
    const tutors = await pool.query(`SELECT "id", "username" FROM "User" WHERE "role" IN ('LECTURER', 'ADMIN') ORDER BY "username" LIMIT 100`)
    return Response.json({ courses: result.rows, tutors: tutors.rows })
  } catch { return jsonError("Academy content is temporarily unavailable.", 503) }
}

export async function POST(request: Request) {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to publish course material.", 401)
  if (!["ADMIN", "LECTURER"].includes(profile.role)) return jsonError("Only approved lecturers can publish courses.", 403)
  let body: unknown
  try { body = await request.json() } catch { return jsonError("Request body must be valid JSON.") }
  const value = body as { title?: unknown; description?: unknown; tutorName?: unknown; lessonTitle?: unknown; lessonDescription?: unknown; contentUrl?: unknown }
  const title = typeof value.title === "string" ? value.title.trim() : ""
  const description = typeof value.description === "string" ? value.description.trim() : ""
  const tutorName = profile.username
  const lessonTitle = typeof value.lessonTitle === "string" ? value.lessonTitle.trim() : ""
  const lessonDescription = typeof value.lessonDescription === "string" ? value.lessonDescription.trim() : ""
  const rawContentUrl = typeof value.contentUrl === "string" && value.contentUrl.length <= 2000 ? value.contentUrl.trim() : ""
  let contentUrl: string | null = null
  if (rawContentUrl) {
    try {
      const parsed = new URL(rawContentUrl)
      if (parsed.protocol !== "https:") return jsonError("Lesson resources must use HTTPS.")
      contentUrl = parsed.toString()
    } catch { return jsonError("Provide a valid HTTPS resource URL.") }
  }
  if (!title || title.length > 120 || !description || description.length > 1000 || !lessonTitle || lessonTitle.length > 120 || !lessonDescription || lessonDescription.length > 1000) return jsonError("Complete the course and first lesson details.")
  try {
    const client = await pool.connect()
    try {
      await client.query("BEGIN")
      const courseId = crypto.randomUUID()
      await client.query(`INSERT INTO "Course" ("id", "authorId", "title", "description", "tutorName") VALUES ($1, $2, $3, $4, $5)`, [courseId, profile.id, title, description, tutorName])
      await client.query(`INSERT INTO "Lesson" ("id", "courseId", "title", "description", "contentUrl", "published") VALUES ($1, $2, $3, $4, $5, true)`, [crypto.randomUUID(), courseId, lessonTitle, lessonDescription, contentUrl])
      await client.query("COMMIT")
      return Response.json({ course: { id: courseId, title, description, tutorName, author: profile.username, lessonCount: 1 } }, { status: 201 })
    } catch (error) { await client.query("ROLLBACK"); throw error }
    finally { client.release() }
  } catch { return jsonError("Could not publish this course.", 503) }
}
