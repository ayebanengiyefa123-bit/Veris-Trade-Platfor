import { getCurrentProfile, jsonError, isValidId } from "@/lib/auth-profile"
import { pool } from "@/lib/db"
import { stripe } from "@/lib/stripe"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

export async function POST(request: Request) {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to enroll in mentorship.", 401)
  if (!stripe) return jsonError("Stripe billing is not configured for this environment.", 503)
  let body: unknown = {}
  try { body = await request.json() } catch { return jsonError("Request body must be valid JSON.", 400) }
  if (typeof body === "object" && body !== null && "action" in body && body.action === "portal") {
    try {
      const current = await pool.query(`SELECT "stripeSubscriptionId" FROM "MentorshipSubscription" WHERE "userId" = $1 AND "stripeSubscriptionId" IS NOT NULL ORDER BY "createdAt" DESC LIMIT 1`, [profile.id])
      const subscriptionId = current.rows[0]?.stripeSubscriptionId
      if (!subscriptionId) return jsonError("No mentorship subscription is linked to this account.", 404)
      const subscription = await stripe.subscriptions.retrieve(subscriptionId)
      const customerId = typeof subscription.customer === "string" ? subscription.customer : subscription.customer.id
      const session = await stripe.billingPortal.sessions.create({ customer: customerId, return_url: `${new URL(request.url).origin}/academy` })
      return Response.json({ url: session.url })
    } catch { return jsonError("Stripe billing management is not available for this subscription.", 503) }
  }
  const tutorId = typeof body === "object" && body !== null && "tutorId" in body && typeof body.tutorId === "string" ? body.tutorId : null
  if (tutorId && !isValidId(tutorId)) return jsonError("Choose a valid tutor.")
  try {
    if (tutorId) {
      const tutor = await pool.query(`SELECT "id" FROM "User" WHERE "id" = $1 AND "role" IN ('LECTURER', 'ADMIN')`, [tutorId])
      if (!tutor.rowCount) return jsonError("This tutor is not accepting mentorship enrollments.", 404)
    }
    const baseUrl = new URL(request.url).origin
    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      ui_mode: "hosted_page",
      client_reference_id: profile.id,
      line_items: [{ price_data: { currency: "usd", unit_amount: 30000, recurring: { interval: "month" }, product_data: { name: "Veris Live Mentorship", description: "Monthly access to live classes and tutor-led study sessions." } }, quantity: 1 }],
      success_url: `${baseUrl}/academy?checkout_session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${baseUrl}/academy?checkout=cancelled`,
      metadata: { userId: profile.id, tutorId: tutorId ?? "" },
      subscription_data: { metadata: { userId: profile.id, tutorId: tutorId ?? "" } },
    })
    await pool.query(`INSERT INTO "MentorshipSubscription" ("id", "userId", "tutorId", "stripeCheckoutSessionId", "status") VALUES ($1, $2, $3, $4, 'PENDING') ON CONFLICT ("stripeCheckoutSessionId") DO NOTHING`, [crypto.randomUUID(), profile.id, tutorId, session.id])
    return Response.json({ url: session.url })
  } catch { return jsonError("Could not start the secure mentorship checkout.", 503) }
}

export async function GET(request: Request) {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to check enrollment.", 401)
  if (!stripe) return jsonError("Stripe billing is not configured for this environment.", 503)
  const sessionId = new URL(request.url).searchParams.get("session_id")
  if (!isValidId(sessionId)) {
    try {
      const result = await pool.query(`SELECT "id", "status", "currentPeriodEnd", "stripeSubscriptionId" FROM "MentorshipSubscription" WHERE "userId" = $1 ORDER BY "createdAt" DESC LIMIT 1`, [profile.id])
      const latest = result.rows[0]
      if (latest?.stripeSubscriptionId) {
        const subscription = await stripe.subscriptions.retrieve(latest.stripeSubscriptionId)
        const periodEndSeconds = subscription.items.data[0]?.current_period_end
        const periodEnd = periodEndSeconds ? new Date(periodEndSeconds * 1000) : null
        const status = subscription.status.toUpperCase()
        await pool.query(`UPDATE "MentorshipSubscription" SET "status" = $1, "currentPeriodEnd" = $2 WHERE "id" = $3 AND "userId" = $4`, [status, periodEnd, latest.id, profile.id])
        return Response.json({ enrollment: { status, currentPeriodEnd: periodEnd?.toISOString() ?? null } })
      }
      return Response.json({ enrollment: latest ? { status: latest.status, currentPeriodEnd: latest.currentPeriodEnd } : null })
    } catch { return jsonError("Enrollment status is temporarily unavailable.", 503) }
  }
  try {
    const session = await stripe.checkout.sessions.retrieve(sessionId, { expand: ["subscription"] })
    if (session.client_reference_id !== profile.id || session.mode !== "subscription" || !session.subscription || !["paid", "no_payment_required"].includes(session.payment_status ?? "")) return jsonError("This checkout has not been confirmed for your account.", 403)
    const subscription = typeof session.subscription === "string" ? await stripe.subscriptions.retrieve(session.subscription) : session.subscription
    if (!["active", "trialing"].includes(subscription.status)) return jsonError("The subscription is not active.", 409)
    const periodEndSeconds = subscription.items.data[0]?.current_period_end
    const periodEnd = periodEndSeconds ? new Date(periodEndSeconds * 1000) : null
    await pool.query(`UPDATE "MentorshipSubscription" SET "stripeSubscriptionId" = $1, "status" = $2, "currentPeriodEnd" = $3 WHERE "stripeCheckoutSessionId" = $4 AND "userId" = $5`, [subscription.id, subscription.status.toUpperCase(), periodEnd, session.id, profile.id])
    return Response.json({ enrollment: { status: subscription.status.toUpperCase(), currentPeriodEnd: periodEnd?.toISOString() ?? null } })
  } catch { return jsonError("Could not confirm your enrollment. Contact support if payment was completed.", 503) }
}
