import { ClerkProvider } from "@clerk/nextjs"
import type { Metadata, Viewport } from "next"
import { Inter, JetBrains_Mono } from "next/font/google"
import { Suspense } from "react"
import "./globals.css"

const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" })
const jetBrainsMono = JetBrains_Mono({ subsets: ["latin"], variable: "--font-jetbrains", display: "swap" })

export const metadata: Metadata = {
  title: { default: "Veris Trade & Trust", template: "%s | Veris" },
  description: "A transparent gateway to digital markets and tokenized private markets.",
  applicationName: "Veris Trade & Trust",
  keywords: ["digital assets", "security tokens", "trading", "education"],
}

export const viewport: Viewport = {
  themeColor: "#030612",
  colorScheme: "dark",
  width: "device-width",
  initialScale: 1,
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  const publishableKey = process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY
  const content = publishableKey ? <ClerkProvider publishableKey={publishableKey} signInUrl="/sign-in" signUpUrl="/sign-up" signUpForceRedirectUrl="/community" signInFallbackRedirectUrl="/dashboard">{children}</ClerkProvider> : children
  return <html lang="en" className={`${inter.variable} ${jetBrainsMono.variable}`}><body><Suspense>{content}</Suspense></body></html>
}
