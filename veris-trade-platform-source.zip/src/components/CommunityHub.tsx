"use client"

import { useState } from "react"
import useSWR from "swr"
import { ArrowUpRight, Heart, MessageCircle, Radio, Users, UsersRound } from "lucide-react"

type ApiError = { error?: string }
const fetcher = async <T,>(url: string): Promise<T> => {
  const response = await fetch(url, { cache: "no-store" }); const data = await response.json()
  if (!response.ok) throw new Error((data as ApiError).error || "Could not load data.")
  return data as T
}
async function sendJson<T>(url: string, method: string, body: unknown): Promise<T> {
  const response = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }); const data = await response.json()
  if (!response.ok) throw new Error(data.error || "Request could not be completed.")
  return data as T
}
type Post = { id: string; content: string; likes: number; commentCount: number; createdAt: string; username: string }
type CommunityData = { posts: Post[] }
type NetworkData = { requests: Array<{ id: string; status: string; fromUserId: string; toUserId: string; fromUsername: string; toUsername: string }> }
type ProfileData = { profile: { id: string; username: string } }
type MessageData = { messages?: Array<{ id: string; content: string; createdAt: string; username: string; senderId?: string }>; connections?: Array<{ id: string; username: string }>; groups?: Array<{ id: string; title: string; status: string }> }
const field = "w-full rounded-lg border border-white/10 bg-[#050a18] px-3 py-2.5 text-sm text-slate-200 outline-none placeholder:text-slate-600 focus:border-cyan-300/40"
const action = "inline-flex items-center justify-center gap-2 rounded-lg bg-cyan-300 px-4 py-2.5 text-xs font-semibold text-slate-950 hover:bg-cyan-200 disabled:opacity-50"

export function CommunityHub() {
  const { data: profile } = useSWR<ProfileData>("/api/profile", fetcher)
  const { data, error, mutate, isLoading } = useSWR<CommunityData>("/api/community/posts", fetcher, { refreshInterval: 15000 })
  const { data: network, mutate: refreshNetwork } = useSWR<NetworkData>("/api/community/friends", fetcher)
  const { data: inbox, mutate: refreshInbox } = useSWR<MessageData>("/api/community/messages", fetcher)
  const [content, setContent] = useState("")
  const [friendName, setFriendName] = useState("")
  const [groupTitle, setGroupTitle] = useState("")
  const [groupUsers, setGroupUsers] = useState("")
  const [activePost, setActivePost] = useState<string | null>(null)
  const [comment, setComment] = useState("")
  const [peerId, setPeerId] = useState("")
  const [groupId, setGroupId] = useState("")
  const [message, setMessage] = useState("")
  const [draftMessage, setDraftMessage] = useState("")
  const [notice, setNotice] = useState("")
  const [busy, setBusy] = useState(false)
  const { data: comments, mutate: refreshComments } = useSWR<{ comments: Array<{ id: string; content: string; username: string; likes: number; createdAt: string }> }>(activePost ? `/api/community/comment?postId=${activePost}` : null, fetcher)
  const conversationKey = groupId ? `/api/community/messages?groupId=${groupId}` : peerId ? `/api/community/messages?with=${peerId}` : null
  const { data: conversation, mutate: refreshConversation } = useSWR<MessageData>(conversationKey, fetcher, { refreshInterval: 7000 })

  async function publish(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setNotice("")
    try { await sendJson("/api/community/posts", "POST", { content }); setContent(""); setNotice("Your post is live."); await mutate() }
    catch (error) { setNotice(error instanceof Error ? error.message : "Could not publish.") }
    finally { setBusy(false) }
  }
  async function toggleLike(postId: string) {
    try { await sendJson("/api/community/like", "POST", { postId }); await mutate() }
    catch (error) { setNotice(error instanceof Error ? error.message : "Could not like this post.") }
  }
  async function publishComment(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (!activePost) return
    try { await sendJson("/api/community/comment", "POST", { postId: activePost, content: comment }); setComment(""); await Promise.all([refreshComments(), mutate()]) }
    catch (error) { setNotice(error instanceof Error ? error.message : "Could not add comment.") }
  }
  async function toggleCommentLike(commentId: string) {
    try { await sendJson("/api/community/comment", "POST", { action: "like", commentId }); await refreshComments() }
    catch (error) { setNotice(error instanceof Error ? error.message : "Could not like this comment.") }
  }
  async function sendFriendRequest(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    try { await sendJson("/api/community/friends", "POST", { username: friendName }); setFriendName(""); setNotice("Connection request sent."); await refreshNetwork() }
    catch (error) { setNotice(error instanceof Error ? error.message : "Could not send request.") }
  }
  async function updateRequest(requestId: string, actionName: "accept" | "decline") {
    try { await sendJson("/api/community/friends", "PATCH", { requestId, action: actionName }); await Promise.all([refreshNetwork(), refreshInbox()]) }
    catch (error) { setNotice(error instanceof Error ? error.message : "Could not update request.") }
  }
  async function publishMessage(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!draftMessage.trim()) return
    try { await sendJson("/api/community/messages", "POST", groupId ? { groupId, content: draftMessage } : { recipientId: peerId, content: draftMessage }); setDraftMessage(""); await refreshConversation() }
    catch (error) { setNotice(error instanceof Error ? error.message : "Could not send message.") }
  }
  async function createGroup(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    try { await sendJson("/api/community/messages", "POST", { action: "create-group", title: groupTitle, usernames: groupUsers.split(",").map((name) => name.trim()).filter(Boolean) }); setGroupTitle(""); setGroupUsers(""); setNotice("Private group created and connection invitations sent."); await refreshInbox() }
    catch (error) { setNotice(error instanceof Error ? error.message : "Could not create group.") }
  }
  async function joinGroup(id: string) {
    try { await sendJson("/api/community/messages", "POST", { action: "join-group", groupId: id }); await refreshInbox() }
    catch (error) { setNotice(error instanceof Error ? error.message : "Could not join group.") }
  }

  const connections = inbox?.connections ?? []
  const groups = inbox?.groups ?? []
  const incoming = network?.requests.filter((request) => request.toUserId === profile?.profile.id && request.status === "PENDING") ?? []
  const outgoing = network?.requests.filter((request) => request.fromUserId === profile?.profile.id && request.status === "PENDING") ?? []

  return <div className="mx-auto max-w-[1320px] px-5 py-10 pb-16 md:px-8">
    <header className="mb-8"><p className="flex items-center gap-2 text-[10px] uppercase tracking-[.2em] text-cyan-200"><Radio size={14}/> Veris Community</p><h1 className="mt-3 text-4xl font-medium tracking-tight">Better markets start<br/><span className="text-slate-400">with better conversations.</span></h1><p className="mt-4 max-w-xl text-sm leading-6 text-slate-400">Share research, connect with other members, and learn together. Messages and connection lists are restricted to your account.</p></header>
    {notice && <p role="status" className="mb-4 rounded-lg border border-cyan-300/10 bg-cyan-300/[.04] px-4 py-3 text-xs text-cyan-100">{notice}</p>}
    <div className="grid items-start gap-5 xl:grid-cols-[minmax(0,1fr)_360px]">
      <section aria-labelledby="feed-title"><form onSubmit={publish} className="glass rounded-xl p-4"><label htmlFor="post-content" className="sr-only">Write a community post</label><textarea id="post-content" value={content} onChange={(event) => setContent(event.target.value)} maxLength={1000} rows={3} placeholder="Share a market thought or ask the community…" className="w-full resize-y bg-transparent text-sm leading-6 text-slate-200 outline-none placeholder:text-slate-600"/><div className="flex flex-wrap items-center justify-between gap-3 border-t border-white/[.06] pt-3"><span className="text-[10px] text-slate-500">Posting as <strong className="text-slate-300">{profile?.profile.username ?? "member"}</strong></span><button className={action} disabled={busy || !content.trim()}>{busy ? "Posting…" : "Publish post"}<ArrowUpRight size={13}/></button></div></form>
        <div className="mb-3 mt-6 flex items-center justify-between"><h2 id="feed-title" className="text-sm font-semibold">Community feed</h2><span className="text-[10px] text-slate-600">Newest first</span></div>
        {isLoading && <p className="py-8 text-center text-xs text-slate-500">Loading community posts…</p>}{error && <p role="status" className="rounded-xl border border-rose-300/10 p-4 text-xs text-rose-200">{error.message}</p>}{!isLoading && !error && !data?.posts.length && <div className="glass rounded-xl p-8 text-center text-xs text-slate-500">No posts yet. Start the conversation.</div>}
        <div className="flex flex-col gap-3">{data?.posts.map((post) => <article key={post.id} className="glass rounded-xl p-5"><div className="flex items-center gap-3"><span className="grid size-9 place-items-center rounded-full bg-cyan-300/[.1] text-xs font-semibold text-cyan-100">{post.username.slice(0, 1).toUpperCase()}</span><div><p className="text-xs font-semibold text-slate-200">{post.username}</p><time className="mt-1 block text-[10px] text-slate-600" dateTime={post.createdAt}>{new Date(post.createdAt).toLocaleString()}</time></div></div><p className="mt-4 whitespace-pre-wrap text-sm leading-6 text-slate-300">{post.content}</p><div className="mt-4 flex gap-2 border-t border-white/[.06] pt-3"><button onClick={() => void toggleLike(post.id)} className="inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-[10px] text-slate-500 hover:bg-white/[.04] hover:text-rose-200" aria-label={`Like post by ${post.username}`}><Heart size={14}/>{post.likes}</button><button onClick={() => { setActivePost(activePost === post.id ? null : post.id); setNotice("") }} className="inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-[10px] text-slate-500 hover:bg-white/[.04] hover:text-cyan-200"><MessageCircle size={14}/>{post.commentCount} comments</button><span className="ml-auto text-[9px] text-slate-600">Like weights reflect recorded holdings; no token rewards are issued.</span></div>
          {activePost === post.id && <div className="mt-4 border-t border-white/[.06] pt-4"><div className="flex flex-col gap-3">{comments?.comments.map((item) => <div key={item.id} className="rounded-lg bg-white/[.025] px-3 py-2.5"><div className="flex justify-between gap-2"><strong className="text-[10px] text-slate-300">{item.username}</strong><span className="text-[9px] text-slate-600">{item.likes} likes</span></div><p className="mt-1 text-xs leading-5 text-slate-400">{item.content}</p><button onClick={() => void toggleCommentLike(item.id)} className="mt-2 inline-flex items-center gap-1 text-[9px] text-slate-500 hover:text-rose-200" aria-label={`Like comment by ${item.username}`}><Heart size={11}/>{item.likes}</button></div>)}</div><form onSubmit={publishComment} className="mt-3 flex gap-2"><label htmlFor={`comment-${post.id}`} className="sr-only">Write a comment</label><input id={`comment-${post.id}`} className={field} maxLength={1000} value={comment} onChange={(event) => setComment(event.target.value)} placeholder="Add a thoughtful comment…"/><button className={action} disabled={!comment.trim()} aria-label="Add comment"><ArrowUpRight size={14}/></button></form></div>}
        </article>)}</div>
      </section>
      <aside className="flex flex-col gap-4">
        <section className="glass rounded-xl p-5" aria-labelledby="network-title"><div className="flex items-center gap-2"><Users size={16} className="text-cyan-200"/><h2 id="network-title" className="text-sm font-semibold">Your network</h2></div><form onSubmit={sendFriendRequest} className="mt-4 flex gap-2"><label htmlFor="member-handle" className="sr-only">Member username</label><input id="member-handle" className={field} value={friendName} onChange={(event) => setFriendName(event.target.value)} placeholder="member_username"/><button className={action} aria-label="Send connection request"><ArrowUpRight size={14}/></button></form>
          {incoming.length > 0 && <div className="mt-4"><p className="text-[10px] uppercase tracking-wider text-slate-500">Requests to you</p>{incoming.map((item) => <div key={item.id} className="mt-2 flex items-center justify-between gap-2 text-xs"><span className="truncate text-slate-300">{item.fromUsername}</span><div className="flex gap-1"><button className="rounded-md bg-cyan-300/10 px-2 py-1 text-[9px] text-cyan-100" onClick={() => void updateRequest(item.id, "accept")}>Accept</button><button className="rounded-md px-2 py-1 text-[9px] text-slate-500 hover:text-slate-200" onClick={() => void updateRequest(item.id, "decline")}>Decline</button></div></div>)}</div>}
          {outgoing.length > 0 && <p className="mt-3 text-[10px] text-slate-600">{outgoing.length} connection request{outgoing.length === 1 ? "" : "s"} awaiting a reply.</p>}
          <div className="mt-4 border-t border-white/[.06] pt-3"><p className="mb-2 text-[10px] uppercase tracking-wider text-slate-500">Accepted connections</p>{!connections.length && <p className="text-xs text-slate-600">No accepted connections yet.</p>}{connections.map((contact) => <button key={contact.id} onClick={() => { setPeerId(contact.id); setGroupId("") }} className={`flex w-full items-center justify-between rounded-lg px-2.5 py-2 text-xs ${peerId === contact.id ? "bg-cyan-300/[.08] text-cyan-100" : "text-slate-400 hover:bg-white/[.03]"}`}><span>{contact.username}</span><MessageCircle size={13}/></button>)}</div>
        </section>
        <section className="glass rounded-xl p-5" aria-labelledby="groups-title"><div className="flex items-center gap-2"><UsersRound size={16} className="text-cyan-200"/><h2 id="groups-title" className="text-sm font-semibold">Private groups</h2></div><form onSubmit={createGroup} className="mt-3 grid gap-2"><label htmlFor="group-title" className="sr-only">Group title</label><input id="group-title" className={field} value={groupTitle} onChange={(event) => setGroupTitle(event.target.value)} maxLength={80} placeholder="Group name" required/><label htmlFor="group-users" className="sr-only">Connection usernames</label><input id="group-users" className={field} value={groupUsers} onChange={(event) => setGroupUsers(event.target.value)} placeholder="Accepted usernames, comma-separated" required/><button className={action}>Create private group</button></form>
          <div className="mt-4 flex flex-col gap-1 border-t border-white/[.06] pt-3">{groups.map((group) => group.status === "INVITED" ? <div key={group.id} className="flex items-center justify-between gap-2 text-xs"><span className="truncate text-slate-400">Invite: {group.title}</span><button onClick={() => void joinGroup(group.id)} className="rounded-md bg-cyan-300/10 px-2 py-1 text-[9px] text-cyan-100">Join</button></div> : <button key={group.id} onClick={() => { setGroupId(group.id); setPeerId("") }} className={`rounded-lg px-2.5 py-2 text-left text-xs ${groupId === group.id ? "bg-cyan-300/[.08] text-cyan-100" : "text-slate-400 hover:bg-white/[.03]"}`}>{group.title}</button>)}</div>
        </section>
        <section className="glass rounded-xl p-5" aria-labelledby="messages-title"><div className="flex items-center justify-between gap-2"><h2 id="messages-title" className="text-sm font-semibold">Private messages</h2><span className="text-[9px] text-slate-600">Connections only</span></div><div className="mt-3 flex min-h-28 max-h-56 flex-col gap-2 overflow-y-auto rounded-lg bg-black/10 p-2">{conversation?.messages?.map((item) => <div key={item.id} className="rounded-lg bg-white/[.035] p-2.5"><p className="text-[9px] text-cyan-100">{item.username}</p><p className="mt-1 break-words text-xs leading-5 text-slate-300">{item.content}</p></div>)}{!conversationKey && <p className="m-auto text-center text-[10px] text-slate-600">Choose a connection or group to open a conversation.</p>}{conversationKey && !conversation?.messages?.length && <p className="m-auto text-center text-[10px] text-slate-600">No messages yet.</p>}</div>{conversationKey && <form onSubmit={publishMessage} className="mt-2 flex gap-2"><label className="sr-only" htmlFor="direct-message">Message</label><input id="direct-message" className={field} maxLength={2000} value={draftMessage} onChange={(event) => setDraftMessage(event.target.value)} placeholder="Write a private message…"/><button className={action} aria-label="Send message" disabled={!draftMessage.trim()}><ArrowUpRight size={14}/></button></form>}</section>
      </aside>
    </div>
  </div>
}
