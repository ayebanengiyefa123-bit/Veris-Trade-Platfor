import { POST as likePost } from "./like/route"

export const dynamic = "force-dynamic"
export { GET, POST } from "./posts/route"

export async function PATCH(request: Request) {
  let body: unknown
  try { body = await request.clone().json() } catch { return Response.json({ error: "Request body must be valid JSON." }, { status: 400 }) }
  const value = body as { postId?: unknown; action?: unknown }
  if (value.action !== "like" || typeof value.postId !== "string") return Response.json({ error: "Unsupported interaction." }, { status: 400 })
  return likePost(request)
}
