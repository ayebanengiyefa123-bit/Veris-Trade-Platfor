import { Pool } from "pg"
import { drizzle } from "drizzle-orm/node-postgres"
import { pgTable, text, numeric, integer, timestamp } from "drizzle-orm/pg-core"

export const users = pgTable("User", {
  id: text("id").primaryKey(), clerkId: text("clerkId").unique(), username: text("username").notNull().unique(),
  email: text("email").unique(), role: text("role").notNull().default("USER"), walletAddress: text("walletAddress").unique(),
  balance: numeric("balance", { precision: 20, scale: 2 }).notNull().default("0"),
  tokenBalance: numeric("tokenBalance", { precision: 28, scale: 8 }).notNull().default("0"),
  createdAt: timestamp("createdAt", { withTimezone: true }).notNull().defaultNow(),
})
export const posts = pgTable("Post", {
  id: text("id").primaryKey(), content: text("content").notNull(), userId: text("userId").notNull(),
  likes: integer("likes").notNull().default(0), reposts: integer("reposts").notNull().default(0),
  createdAt: timestamp("createdAt", { withTimezone: true }).notNull().defaultNow(),
})
export const investments = pgTable("Investment", {
  id: text("id").primaryKey(), userId: text("userId").notNull(),
  depositAmount: numeric("depositAmount", { precision: 20, scale: 2 }).notNull(),
  tokensMinted: numeric("tokensMinted", { precision: 28, scale: 8 }).notNull(),
  equityPercent: numeric("equityPercent", { precision: 12, scale: 8 }).notNull(),
  status: text("status").notNull().default("PENDING"), createdAt: timestamp("createdAt", { withTimezone: true }).notNull().defaultNow(),
})

const globalForPool = globalThis as typeof globalThis & { verisPool?: Pool }
export const pool = globalForPool.verisPool ?? new Pool({ connectionString: process.env.DATABASE_URL, max: 5, idleTimeoutMillis: 10000 })
if (process.env.NODE_ENV !== "production") globalForPool.verisPool = pool
export const db = drizzle(pool, { schema: { users, posts, investments } })
