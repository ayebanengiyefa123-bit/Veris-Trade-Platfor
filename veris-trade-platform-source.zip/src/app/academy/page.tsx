import type { Metadata } from "next"
import { PlatformPage } from "@/components/PlatformPage"
export const metadata: Metadata = { title: "Veris Academy" }
export default function AcademyPage() { return <PlatformPage view="academy"/> }
