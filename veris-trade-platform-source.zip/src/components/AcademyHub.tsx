"use client"

import { useState } from "react"
import { useSearchParams } from "next/navigation"
import useSWR from "swr"
import { ArrowUpRight, BookOpen, CalendarDays, Check, Clock3, GraduationCap, LockKeyhole, UserRound } from "lucide-react"

type ApiError = { error?: string }
const fetcher = async <T,>(url: string): Promise<T> => {
  const response = await fetch(url, { cache: "no-store" }); const data = await response.json()
  if (!response.ok) throw new Error((data as ApiError).error || "Could not load data.")
  return data as T
}
async function postJson<T>(url: string, body: unknown): Promise<T> {
  const response = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }); const data = await response.json()
  if (!response.ok) throw new Error(data.error || "Request could not be completed.")
  return data as T
}
const field = "mt-1.5 w-full rounded-lg border border-white/10 bg-[#050a18] px-3 py-2.5 text-sm text-slate-100 outline-none focus:border-cyan-300/40"
const button = "inline-flex items-center justify-center gap-2 rounded-lg bg-cyan-300 px-4 py-2.5 text-xs font-semibold text-slate-950 hover:bg-cyan-200 disabled:opacity-50"
const guidedModules = [
  { category: "DIGITAL ASSETS", title: "Digital asset foundations", description: "Understand wallets, token standards, custody, and market structure.", duration: "12 min", level: "Beginner", icon: BookOpen },
  { category: "MARKET STRUCTURE", title: "How exchanges work", description: "Explore order books, liquidity, spreads, and execution risk.", duration: "14 min", level: "Beginner", icon: Clock3 },
  { category: "VERIS PLATFORM", title: "How an STO allocation works", description: "Follow the lifecycle from offering documents to ownership records.", duration: "10 min", level: "Beginner", icon: GraduationCap },
  { category: "SECURITY", title: "Smart contract guardrails", description: "Learn how allowlists and compliance checks can constrain transfers.", duration: "16 min", level: "Intermediate", icon: LockKeyhole },
]
type ProfileResult = { profile: { role: string; username: string } }
type AcademyData = { courses: Array<{ id: string; title: string; description: string; tutorName: string; author: string; lessonCount: number }>; tutors: Array<{ id: string; username: string }> }
type CourseDetail = { course: { id: string; title: string; description: string; tutorName: string }; lessons: Array<{ id: string; title: string; description: string; contentUrl: string | null; completed: boolean }> }
type ProgressData = { completed: Array<{ lessonId: string }> }
type SessionData = { sessions: Array<{ id: string; title: string; scheduledAt: string; meetingUrl: string; courseTitle: string | null; tutor: string }>; accessRequired?: boolean }
type EnrollmentData = { enrollment: { status: string; currentPeriodEnd?: string } | null }

export function AcademyHub() {
  const searchParams = useSearchParams()
  const checkoutSession = searchParams.get("checkout_session_id")
  const checkoutCancelled = searchParams.get("checkout") === "cancelled"
  const { data: profile } = useSWR<ProfileResult>("/api/profile", fetcher)
  const { data: academy, error, mutate: refreshAcademy } = useSWR<AcademyData>("/api/academy/courses", fetcher)
  const { data: progress, mutate: refreshProgress } = useSWR<ProgressData>("/api/academy/progress", fetcher)
  const { data: enrollment, mutate: refreshEnrollment } = useSWR<EnrollmentData>(checkoutSession ? `/api/academy/mentorship?session_id=${encodeURIComponent(checkoutSession)}` : "/api/academy/mentorship", fetcher)
  const { data: sessions, mutate: refreshSessions } = useSWR<SessionData>("/api/academy/sessions", fetcher)
  const [selectedCourse, setSelectedCourse] = useState<string | null>(null)
  const { data: detail, mutate: refreshDetail } = useSWR<CourseDetail>(selectedCourse ? `/api/academy/courses/${selectedCourse}` : null, fetcher)
  const [tutorId, setTutorId] = useState("")
  const [busy, setBusy] = useState(false)
  const [notice, setNotice] = useState("")
  const [courseTitle, setCourseTitle] = useState("")
  const [courseDescription, setCourseDescription] = useState("")
  const [lessonTitle, setLessonTitle] = useState("")
  const [lessonDescription, setLessonDescription] = useState("")
  const [contentUrl, setContentUrl] = useState("")
  const [sessionTitle, setSessionTitle] = useState("")
  const [sessionDate, setSessionDate] = useState("")
  const [meetingUrl, setMeetingUrl] = useState("")
  const [selectedCourseForSession, setSelectedCourseForSession] = useState("")
  const isLecturer = ["ADMIN", "LECTURER"].includes(profile?.profile.role ?? "")

  async function beginMentorship() {
    setBusy(true); setNotice("")
    try {
      const result = await postJson<{ url: string | null }>("/api/academy/mentorship", { tutorId: tutorId || null })
      if (!result.url) throw new Error("Stripe did not return a hosted checkout link.")
      window.location.assign(result.url)
    } catch (error) { setNotice(error instanceof Error ? error.message : "Could not start checkout.") }
    finally { setBusy(false) }
  }
  async function manageMentorship() {
    setBusy(true); setNotice("")
    try {
      const result = await postJson<{ url: string }>("/api/academy/mentorship", { action: "portal" })
      window.location.assign(result.url)
    } catch (error) { setNotice(error instanceof Error ? error.message : "Could not open billing management.") }
    finally { setBusy(false) }
  }
  async function completeLesson(lessonId: string) {
    try { await postJson("/api/academy/progress", { lessonId }); await Promise.all([refreshDetail(), refreshProgress()]) }
    catch (error) { setNotice(error instanceof Error ? error.message : "Could not save lesson progress.") }
  }
  async function publishCourse(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setNotice("")
    try {
      const result = await postJson<{ course: { id: string } }>("/api/academy/courses", { title: courseTitle, description: courseDescription, lessonTitle, lessonDescription, contentUrl: contentUrl || null })
      setSelectedCourse(result.course.id); setCourseTitle(""); setCourseDescription(""); setLessonTitle(""); setLessonDescription(""); setContentUrl(""); await refreshAcademy(); setNotice("Course published.")
    } catch (error) { setNotice(error instanceof Error ? error.message : "Could not publish course.") }
    finally { setBusy(false) }
  }
  async function publishSession(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setNotice("")
    try { await postJson("/api/academy/sessions", { title: sessionTitle, scheduledAt: new Date(sessionDate).toISOString(), meetingUrl, courseId: selectedCourseForSession || null }); setSessionTitle(""); setSessionDate(""); setMeetingUrl(""); await refreshSessions(); setNotice("Live class scheduled.") }
    catch (error) { setNotice(error instanceof Error ? error.message : "Could not schedule class.") }
    finally { setBusy(false) }
  }

  const completedCount = progress?.completed.length ?? 0
  return <div className="mx-auto max-w-[1320px] px-5 py-10 pb-16 md:px-8"><header className="mb-8 grid gap-7 md:grid-cols-[1fr_auto] md:items-end"><div><p className="flex items-center gap-2 text-[10px] uppercase tracking-[.2em] text-cyan-200"><GraduationCap size={14}/> Veris Academy</p><h1 className="mt-3 text-4xl font-medium tracking-tight">Learn the market.<br/><span className="text-slate-400">Build conviction carefully.</span></h1><p className="mt-4 max-w-xl text-sm leading-6 text-slate-400">Self-paced learning, instructor-led courses, live classes, and a $300/month mentorship tier.</p></div><div className="glass min-w-52 rounded-xl p-4"><p className="text-[10px] text-slate-500">Your learning record</p><p className="mt-2 text-sm">{completedCount} published lesson{completedCount === 1 ? "" : "s"} completed</p><div className="mt-3 h-1.5 rounded-full bg-white/[.06]"><div className="h-full rounded-full bg-cyan-300 transition-all" style={{ width: `${Math.min(100, completedCount * 10)}%` }}/></div></div></header>
    {(checkoutCancelled || notice) && <p role="status" className="mb-4 rounded-lg border border-cyan-300/10 bg-cyan-300/[.04] px-4 py-3 text-xs text-cyan-100">{notice || "Checkout was cancelled. No subscription was started."}</p>}
    {checkoutSession && enrollment?.enrollment?.status && <p role="status" className="mb-4 rounded-lg border border-emerald-300/10 bg-emerald-300/[.04] px-4 py-3 text-xs text-emerald-100">Mentorship subscription confirmed: {enrollment.enrollment.status.toLowerCase()}.</p>}
    <section className="mb-8" aria-labelledby="guided-title"><div className="mb-4 flex items-end justify-between"><div><p className="text-[10px] uppercase tracking-[.18em] text-cyan-200">Learning modules</p><h2 id="guided-title" className="mt-1 text-lg font-semibold">Guided learning</h2></div><span className="text-[10px] text-slate-500">Self-paced resources</span></div><div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">{guidedModules.map(({ category, title, description, duration, level, icon: Icon }, index) => <article key={title} className="glass rounded-xl p-5"><div className="flex items-start justify-between"><span className="grid size-10 place-items-center rounded-xl bg-cyan-300/[.08] text-cyan-200"><Icon size={18}/></span><span className="mono text-[10px] text-slate-600">0{index + 1}</span></div><p className="mt-5 text-[9px] tracking-[.18em] text-cyan-200">{category}</p><h3 className="mt-2 text-sm font-semibold">{title}</h3><p className="mt-2 min-h-10 text-xs leading-5 text-slate-500">{description}</p><p className="mt-4 text-[10px] text-slate-600">{duration} · {level}</p></article>)}</div></section>
    <section className="mb-8" aria-labelledby="courses-title"><div className="mb-4 flex items-end justify-between"><div><p className="text-[10px] uppercase tracking-[.18em] text-cyan-200">Instructor-led</p><h2 id="courses-title" className="mt-1 text-lg font-semibold">Published courses</h2></div><span className="text-[10px] text-slate-500">Completion saved to your account</span></div>{error && <p className="text-xs text-rose-300">{error.message}</p>}{!error && !academy?.courses.length && <div className="glass rounded-xl border border-dashed border-white/10 p-6 text-xs leading-5 text-slate-500">No instructor courses have been published. Self-paced modules are available above.</div>}<div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">{academy?.courses.map((course) => <button key={course.id} onClick={() => setSelectedCourse(selectedCourse === course.id ? null : course.id)} className={`glass rounded-xl p-5 text-left transition hover:border-cyan-300/20 ${selectedCourse === course.id ? "border-cyan-300/30" : ""}`}><div className="flex items-center justify-between gap-2"><span className="grid size-9 place-items-center rounded-lg bg-cyan-300/[.08] text-cyan-200"><BookOpen size={17}/></span><span className="text-[10px] text-slate-500">{course.lessonCount} lessons</span></div><h3 className="mt-4 text-sm font-semibold">{course.title}</h3><p className="mt-2 line-clamp-3 text-xs leading-5 text-slate-500">{course.description}</p><p className="mt-4 text-[10px] text-slate-600">Tutor {course.tutorName} · by {course.author}</p></button>)}</div>{detail && selectedCourse && <div className="glass mt-4 rounded-xl p-5"><div className="flex flex-wrap items-start justify-between gap-2"><div><h3 className="text-sm font-semibold">{detail.course.title}</h3><p className="mt-1 text-xs text-slate-500">{detail.course.description}</p></div><button className="text-xs text-slate-500 hover:text-white" onClick={() => setSelectedCourse(null)}>Close lessons</button></div><div className="mt-4 flex flex-col gap-2">{detail.lessons.map((lesson) => <article key={lesson.id} className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-white/[.06] px-4 py-3"><div><h4 className="text-xs font-medium text-slate-200">{lesson.title}</h4><p className="mt-1 text-[10px] leading-4 text-slate-500">{lesson.description}</p>{lesson.contentUrl && <a href={lesson.contentUrl} target="_blank" rel="noopener noreferrer" className="mt-2 inline-flex items-center gap-1 text-[10px] text-cyan-200">Open lesson resource <ArrowUpRight size={12}/></a>}</div>{lesson.completed ? <span className="inline-flex items-center gap-1 text-[10px] text-emerald-200"><Check size={13}/> Completed</span> : <button onClick={() => void completeLesson(lesson.id)} className={button}>Mark complete</button>}</article>)}</div></div>}</section>
    <section className="mb-8 grid gap-5 lg:grid-cols-[1fr_.8fr]" aria-labelledby="mentorship-title"><div className="glass rounded-2xl p-6 md:p-7"><p className="text-[10px] uppercase tracking-[.18em] text-cyan-200">Monthly mentorship</p><h2 id="mentorship-title" className="mt-2 text-2xl font-medium">Learn with a live instructor.</h2><p className="mt-3 max-w-xl text-sm leading-6 text-slate-400">Choose an available tutor and enroll in live classes for $300 per month. Payment is handled through Stripe Checkout; access is granted only after the subscription is confirmed.</p><div className="mt-5 grid gap-3 sm:grid-cols-[1fr_auto] sm:items-end"><label className="text-xs text-slate-400">Choose a tutor<select value={tutorId} onChange={(event) => setTutorId(event.target.value)} className={field}><option value="">Any available instructor</option>{academy?.tutors.map((tutor) => <option key={tutor.id} value={tutor.id}>{tutor.username}</option>)}</select></label><button onClick={() => void beginMentorship()} disabled={busy} className={button}>{busy ? "Opening checkout…" : "Enroll for $300 / month"}<ArrowUpRight size={14}/></button></div>{enrollment?.enrollment && <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-emerald-300/10 bg-emerald-300/[.04] p-3"><p className="text-xs text-emerald-100">Subscription: {enrollment.enrollment.status.toLowerCase()}{enrollment.enrollment.currentPeriodEnd ? ` · period ends ${new Date(enrollment.enrollment.currentPeriodEnd).toLocaleDateString()}` : ""}</p>{["ACTIVE", "TRIALING"].includes(enrollment.enrollment.status) && <button onClick={() => void manageMentorship()} disabled={busy} className="text-[10px] text-cyan-100 underline underline-offset-4">Manage billing</button>}</div>}<p className="mt-3 text-[10px] text-slate-600">Recurring monthly subscription. Payment and cancellation are managed through Stripe’s secure customer portal.</p></div>
      <div className="glass rounded-2xl p-6"><div className="flex items-center gap-2"><CalendarDays size={17} className="text-cyan-200"/><h2 className="text-sm font-semibold">Upcoming live classes</h2></div>{sessions?.accessRequired && <p className="mt-3 text-xs leading-5 text-slate-500">Active mentorship enrollment is required to access live class schedules.</p>}{!sessions?.accessRequired && !sessions?.sessions.length && <p className="mt-3 text-xs text-slate-500">No upcoming sessions have been scheduled.</p>}<div className="mt-3 flex flex-col gap-2">{sessions?.sessions.map((session) => <article key={session.id} className="rounded-lg border border-white/[.06] p-3"><h3 className="text-xs font-semibold">{session.title}</h3><p className="mt-1 text-[10px] text-slate-500">{new Date(session.scheduledAt).toLocaleString()} · {session.tutor}{session.courseTitle ? ` · ${session.courseTitle}` : ""}</p><a href={session.meetingUrl} target="_blank" rel="noopener noreferrer" className="mt-2 inline-flex items-center gap-1 text-[10px] text-cyan-200">Join class <ArrowUpRight size={12}/></a></article>)}</div></div>
    </section>
    {isLecturer && <section className="mb-8 grid gap-5 lg:grid-cols-2" aria-label="Instructor controls"><form onSubmit={publishCourse} className="glass rounded-xl p-5"><div className="mb-4 flex items-center gap-2"><UserRound size={16} className="text-cyan-200"/><h2 className="text-sm font-semibold">Instructor: publish a course</h2></div><div className="grid gap-3"><label className="text-xs text-slate-400">Course title<input className={field} maxLength={120} value={courseTitle} onChange={(event) => setCourseTitle(event.target.value)} required/></label><label className="text-xs text-slate-400">Course overview<textarea className={`${field} resize-y`} rows={2} maxLength={1000} value={courseDescription} onChange={(event) => setCourseDescription(event.target.value)} required/></label><label className="text-xs text-slate-400">First lesson title<input className={field} maxLength={120} value={lessonTitle} onChange={(event) => setLessonTitle(event.target.value)} required/></label><label className="text-xs text-slate-400">Lesson description<textarea className={`${field} resize-y`} rows={2} maxLength={1000} value={lessonDescription} onChange={(event) => setLessonDescription(event.target.value)} required/></label><label className="text-xs text-slate-400">Optional HTTPS resource URL<input className={field} type="url" value={contentUrl} onChange={(event) => setContentUrl(event.target.value)} placeholder="https://…"/></label><button disabled={busy} className={button}>Publish course</button></div></form>
      <form onSubmit={publishSession} className="glass rounded-xl p-5"><div className="mb-4 flex items-center gap-2"><CalendarDays size={16} className="text-cyan-200"/><h2 className="text-sm font-semibold">Instructor: schedule a live class</h2></div><div className="grid gap-3"><label className="text-xs text-slate-400">Class title<input className={field} maxLength={120} value={sessionTitle} onChange={(event) => setSessionTitle(event.target.value)} required/></label><label className="text-xs text-slate-400">Start time<input className={field} type="datetime-local" value={sessionDate} onChange={(event) => setSessionDate(event.target.value)} required/></label><label className="text-xs text-slate-400">HTTPS meeting link<input className={field} type="url" value={meetingUrl} onChange={(event) => setMeetingUrl(event.target.value)} placeholder="https://…" required/></label><label className="text-xs text-slate-400">Associated course<select className={field} value={selectedCourseForSession} onChange={(event) => setSelectedCourseForSession(event.target.value)}><option value="">No course</option>{academy?.courses.map((course) => <option key={course.id} value={course.id}>{course.title}</option>)}</select></label><button disabled={busy} className={button}>Schedule session</button></div></form></section>}
    <p className="text-[10px] leading-5 text-slate-600">Educational material is for informational purposes only and is not investment, legal, tax, or financial advice. Subscription processing and instructor-set meeting links are separate services.</p>
  </div>
}
