// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract VerisSecurityToken {
    string public name = "Veris Security Token";
    string public symbol = "VST";
    uint8 public constant decimals = 18;
    uint256 public immutable maxSupply;
    uint256 public totalSupply;
    uint256 public backerTokensMinted;
    uint256 public constant BACKER_POOL_BPS = 4_000;
    address public owner;

    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;
    mapping(address => bool) public isEligible;

    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed holder, address indexed spender, uint256 value);
    event EligibilityUpdated(address indexed account, bool eligible);
    event BackerAllocationMinted(address indexed recipient, uint256 amount);
    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    modifier onlyOwner() {
        require(msg.sender == owner, "Not authorized");
        _;
    }

    constructor(uint256 supplyCap) {
        require(supplyCap > 0, "Supply cap required");
        owner = msg.sender;
        maxSupply = supplyCap;
        isEligible[msg.sender] = true;
        emit OwnershipTransferred(address(0), msg.sender);
    }

    function setEligible(address account, bool eligible) external onlyOwner {
        require(account != address(0), "Invalid account");
        isEligible[account] = eligible;
        emit EligibilityUpdated(account, eligible);
    }

    function mintBacker(address recipient, uint256 amount) external onlyOwner {
        require(isEligible[recipient], "Recipient not eligible");
        require(amount > 0, "Amount required");
        require(totalSupply + amount <= maxSupply, "Supply cap exceeded");
        require(backerTokensMinted + amount <= (maxSupply * BACKER_POOL_BPS) / 10_000, "Backer pool cap exceeded");
        backerTokensMinted += amount;
        totalSupply += amount;
        balanceOf[recipient] += amount;
        emit Transfer(address(0), recipient, amount);
        emit BackerAllocationMinted(recipient, amount);
    }

    function mint(address recipient, uint256 amount) external onlyOwner {
        require(isEligible[recipient], "Recipient not eligible");
        require(amount > 0, "Amount required");
        require(totalSupply + amount <= maxSupply, "Supply cap exceeded");
        totalSupply += amount;
        balanceOf[recipient] += amount;
        emit Transfer(address(0), recipient, amount);
    }

    function approve(address spender, uint256 amount) external returns (bool) {
        require(isEligible[msg.sender] && isEligible[spender], "Address not eligible");
        allowance[msg.sender][spender] = amount;
        emit Approval(msg.sender, spender, amount);
        return true;
    }

    function transfer(address recipient, uint256 amount) external returns (bool) {
        _transfer(msg.sender, recipient, amount);
        return true;
    }

    function transferFrom(address sender, address recipient, uint256 amount) external returns (bool) {
        uint256 permitted = allowance[sender][msg.sender];
        require(permitted >= amount, "Allowance exceeded");
        allowance[sender][msg.sender] = permitted - amount;
        emit Approval(sender, msg.sender, allowance[sender][msg.sender]);
        _transfer(sender, recipient, amount);
        return true;
    }

    function transferOwnership(address newOwner) external onlyOwner {
        require(newOwner != address(0), "Invalid owner");
        address previousOwner = owner;
        owner = newOwner;
        emit OwnershipTransferred(previousOwner, newOwner);
    }

    function _transfer(address sender, address recipient, uint256 amount) internal {
        require(isEligible[sender] && isEligible[recipient], "Transfer restricted by compliance");
        require(amount > 0, "Amount required");
        require(balanceOf[sender] >= amount, "Insufficient balance");
        balanceOf[sender] -= amount;
        balanceOf[recipient] += amount;
        emit Transfer(sender, recipient, amount);
    }
}
