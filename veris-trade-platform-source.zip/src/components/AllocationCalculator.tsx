"use client"

import { useMemo, useState } from "react"
import { ArrowRight, Check, LoaderCircle } from "lucide-react"

export function AllocationCalculator() {
  const [amount, setAmount] = useState(2500)
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState("")
  const tokens = useMemo(() => amount * 10, [amount])
  const equity = useMemo(() => Math.min((amount / 25_000_000) * 40, 40), [amount])
  async function requestQuote() {
    setBusy(true); setMessage("")
    try {
      const response = await fetch("/api/sto", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ amount }) })
      const result = await response.json()
      if (!response.ok) throw new Error(result.error || "Unable to calculate allocation")
      setMessage(`Quote ${result.quoteId} ready · indicative only`)
    } catch (error) { setMessage(error instanceof Error ? error.message : "Unable to calculate allocation") }
    finally { setBusy(false) }
  }
  return <div className="glass rounded-2xl p-5 sm:p-6">
    <div className="mb-5 flex items-center justify-between"><div><p className="text-[11px] uppercase tracking-[.18em] text-slate-500">STO allocation preview</p><h3 className="mt-1 text-lg font-semibold">Explore your allocation</h3></div><span className="rounded-full border border-emerald-400/20 bg-emerald-400/[.08] px-2.5 py-1 text-[10px] text-emerald-300">40% pool cap</span></div>
    <label htmlFor="investment" className="text-xs text-slate-400">Indicative amount (USD)</label>
    <div className="mt-2 flex items-center rounded-xl border border-white/10 bg-[#050a18] px-4 py-3 focus-within:border-cyan-300/40"><span className="mr-2 text-slate-500">$</span><input id="investment" type="number" min="100" max="25000000" step="100" value={amount} onChange={e => setAmount(Math.max(100, Math.min(25_000_000, Number(e.target.value) || 100)))} className="mono w-full bg-transparent text-lg text-white outline-none"/><span className="text-xs text-slate-500">USD</span></div>
    <input aria-label="Investment amount slider" type="range" min="100" max="250000" step="100" value={Math.min(amount,250000)} onChange={e => setAmount(Number(e.target.value))} className="mt-4 w-full accent-cyan-300"/>
    <div className="mt-5 grid grid-cols-2 gap-3"><div className="rounded-xl border border-white/[.07] bg-white/[.025] p-3"><p className="text-[10px] text-slate-500">Illustrative tokens</p><p className="mono mt-1 text-lg text-cyan-200">{tokens.toLocaleString()}</p></div><div className="rounded-xl border border-white/[.07] bg-white/[.025] p-3"><p className="text-[10px] text-slate-500">Potential pool share</p><p className="mono mt-1 text-lg text-emerald-300">{equity.toFixed(5)}%</p></div></div>
    <button disabled={busy} onClick={requestQuote} className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-cyan-300 py-3 text-sm font-semibold text-slate-950 transition hover:bg-cyan-200 disabled:opacity-60">{busy ? <LoaderCircle className="animate-spin" size={16}/> : <ArrowRight size={16}/>} Get indicative quote</button>
    {message && <p role="status" className="mt-3 flex items-center gap-1.5 text-xs text-cyan-200"><Check size={13}/>{message}</p>}
    <p className="mt-4 text-[10px] leading-relaxed text-slate-500">Illustrative calculator only. Token and equity values are assumptions, not an offer, guarantee, or transaction. No funds are accepted here.</p>
  </div>
}
