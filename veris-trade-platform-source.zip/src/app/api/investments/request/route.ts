import { getCurrentProfile, jsonError } from "@/lib/auth-profile"
import { pool } from "@/lib/db"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

export async function GET() {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to view investment requests.", 401)
  try {
    const result = await pool.query(`SELECT "id", "amount"::text, "currency", "strategy", "status", "createdAt" FROM "InvestmentRequest" WHERE "userId" = $1 ORDER BY "createdAt" DESC LIMIT 50`, [profile.id])
    return Response.json({ requests: result.rows })
  } catch { return jsonError("Investment requests are temporarily unavailable.", 503) }
}

export async function POST(request: Request) {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to submit an investment request.", 401)
  let body: unknown
  try { body = await request.json() } catch { return jsonError("Request body must be valid JSON.") }
  const value = body as { amount?: unknown; strategy?: unknown }
  const amount = Number(value?.amount)
  const strategy = typeof value?.strategy === "string" ? value.strategy.trim() : ""
  if (!Number.isFinite(amount) || amount < 100 || amount > 1_000_000) return jsonError("Enter an amount from $100 to $1,000,000.")
  if (!strategy || strategy.length > 80) return jsonError("Choose a delegation strategy.")
  try {
    const result = await pool.query(`INSERT INTO "InvestmentRequest" ("id", "userId", "amount", "strategy") VALUES ($1, $2, $3, $4) RETURNING "id", "amount"::text, "currency", "strategy", "status", "createdAt"`, [crypto.randomUUID(), profile.id, amount.toFixed(2), strategy])
    return Response.json({ request: result.rows[0], notice: "Request recorded for review. This does not place a trade or transfer funds." }, { status: 201 })
  } catch { return jsonError("Could not save your investment request.", 503) }
}
