import { getCurrentProfile, isValidId, jsonError } from "@/lib/auth-profile"
import { pool } from "@/lib/db"

export const runtime = "nodejs"

export async function POST(request: Request) {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to like a post.", 401)
  let body: unknown
  try { body = await request.json() } catch { return jsonError("Request body must be valid JSON.") }
  const postId = typeof body === "object" && body !== null && "postId" in body ? body.postId : null
  if (!isValidId(postId)) return jsonError("Choose a valid post.")

  const client = await pool.connect()
  try {
    await client.query("BEGIN")
    const existing = await client.query(`SELECT "id" FROM "PostLike" WHERE "postId" = $1 AND "userId" = $2`, [postId, profile.id])
    if (existing.rowCount) {
      await client.query(`DELETE FROM "PostLike" WHERE "postId" = $1 AND "userId" = $2`, [postId, profile.id])
      await client.query(`UPDATE "Post" SET "likes" = GREATEST("likes" - 1, 0) WHERE "id" = $1`, [postId])
    } else {
      const post = await client.query(`SELECT "id" FROM "Post" WHERE "id" = $1`, [postId])
      if (!post.rowCount) { await client.query("ROLLBACK"); return jsonError("Post not found.", 404) }
      await client.query(`INSERT INTO "PostLike" ("id", "postId", "userId") VALUES ($1, $2, $3)`, [crypto.randomUUID(), postId, profile.id])
      await client.query(`UPDATE "Post" SET "likes" = "likes" + 1 WHERE "id" = $1`, [postId])
    }
    await client.query(
      `WITH totals AS (
         SELECT "postId", sum(GREATEST(u."tokenBalance", 0)) AS holdings
         FROM "PostLike" l JOIN "User" u ON u."id" = l."userId"
         WHERE l."postId" = $1 GROUP BY "postId"
       )
       UPDATE "PostLike" l SET "holdingWeight" = CASE WHEN totals.holdings > 0 THEN
         (GREATEST(u."tokenBalance", 0) / totals.holdings)::numeric(12,8) ELSE 0 END
       FROM "User" u, totals WHERE l."postId" = $1 AND u."id" = l."userId"`, [postId],
    )
    const result = await client.query(`SELECT "likes" FROM "Post" WHERE "id" = $1`, [postId])
    await client.query("COMMIT")
    return Response.json({ likes: result.rows[0].likes, reward: "Holding-weighted share recorded for review; no tokens are issued or transferred." })
  } catch {
    await client.query("ROLLBACK")
    return jsonError("Could not update this post.", 503)
  } finally { client.release() }
}
