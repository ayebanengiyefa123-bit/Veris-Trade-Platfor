import { getCurrentProfile, jsonError } from "@/lib/auth-profile"
import { pool } from "@/lib/db"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

export async function GET() {
  try {
    const profile = await getCurrentProfile()
    if (!profile) return jsonError("Sign in to continue.", 401)
    const [compliance, wallets, entries] = await Promise.all([
      pool.query(`SELECT "countryCode", "jurisdiction", "status", "updatedAt" FROM "UserCompliance" WHERE "userId" = $1`, [profile.id]),
      pool.query(`SELECT "address", "provider", "status", "createdAt" FROM "WalletConnection" WHERE "userId" = $1 ORDER BY "createdAt" DESC`, [profile.id]),
      pool.query(`SELECT "id", "entryType", "amount"::text, "asset", "status", "description", "createdAt" FROM "LedgerEntry" WHERE "userId" = $1 ORDER BY "createdAt" DESC LIMIT 20`, [profile.id]),
    ])
    return Response.json({ profile, compliance: compliance.rows[0] ?? null, wallets: wallets.rows, ledger: entries.rows })
  } catch {
    return jsonError("Your profile is temporarily unavailable.", 503)
  }
}
