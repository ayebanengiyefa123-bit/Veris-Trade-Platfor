import type { Metadata } from "next"
import { PlatformPage } from "@/components/PlatformPage"
export const metadata: Metadata = { title: "Financing & STO" }
export default function FinancingPage() { return <PlatformPage view="financing"/> }
