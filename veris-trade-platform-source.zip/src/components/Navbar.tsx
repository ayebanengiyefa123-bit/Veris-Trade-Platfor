"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { useState } from "react"
import { Show, UserButton } from "@clerk/nextjs"
import { ArrowUpRight, Menu, X } from "lucide-react"

const links = [
  ["Markets", "/dashboard"], ["Financing", "/financing"], ["Credit access", "/loans"], ["Academy", "/academy"], ["Community", "/community"],
] as const
const clerkConfigured = Boolean(process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY)

function AccountActions({ mobile = false, onNavigate }: { mobile?: boolean; onNavigate?: () => void }) {
  const base = mobile ? "flex-1 rounded-lg px-3 py-3 text-center text-sm" : "rounded-lg px-3 py-2 text-[13px]"
  if (!clerkConfigured) return <><Link href="/sign-in" onClick={onNavigate} className={`${base} text-slate-300 hover:text-white`}>Sign in</Link><Link href="/sign-up" onClick={onNavigate} className={`${base} bg-cyan-300 font-semibold text-slate-950 hover:bg-cyan-200`}>Open account <ArrowUpRight className="ml-1 inline" size={14}/></Link></>
  return <><Show when="signed-out"><Link href="/sign-in" onClick={onNavigate} className={`${base} text-slate-300 hover:text-white`}>Sign in</Link><Link href="/sign-up" onClick={onNavigate} className={`${base} bg-cyan-300 font-semibold text-slate-950 hover:bg-cyan-200`}>Open account <ArrowUpRight className="ml-1 inline" size={14}/></Link></Show><Show when="signed-in"><Link href="/dashboard" onClick={onNavigate} className={`${base} text-slate-300 hover:text-white`}>My workspace</Link><span className="inline-flex items-center px-2"><UserButton/></span></Show></>
}

export function Navbar() {
  const pathname = usePathname()
  const [open, setOpen] = useState(false)
  const closeMenu = () => setOpen(false)
  return <header className="sticky top-0 z-40 border-b border-white/[.06] bg-[#030612]/85 backdrop-blur-xl">
    <div className="mx-auto flex h-[72px] max-w-[1320px] items-center justify-between px-5 md:px-8">
      <Link href="/" className="flex items-center gap-3" aria-label="Veris home">
        <span className="grid size-9 place-items-center rounded-xl border border-cyan-300/30 bg-cyan-300/[.08] text-cyan-200"><span className="text-lg font-semibold">V</span></span>
        <span className="leading-tight"><strong className="block text-[15px] tracking-wide">VERIS</strong><small className="text-[9px] tracking-[.22em] text-slate-500">TRADE & TRUST</small></span>
      </Link>
      <nav className="hidden items-center gap-6 lg:flex" aria-label="Main navigation">
        {links.map(([label, href]) => <Link key={href} href={href} className={`text-[12px] transition hover:text-cyan-200 ${pathname === href ? "text-cyan-200" : "text-slate-400"}`}>{label}</Link>)}
      </nav>
      <div className="hidden items-center gap-3 sm:flex"><AccountActions/></div>
      <button type="button" className="grid size-10 place-items-center rounded-lg border border-white/10 text-slate-200 lg:hidden" aria-label={open ? "Close menu" : "Open menu"} aria-expanded={open} aria-controls="mobile-navigation" onClick={() => setOpen(!open)}>{open ? <X size={19}/> : <Menu size={19}/>}</button>
    </div>
    {open && <nav id="mobile-navigation" className="border-t border-white/[.06] px-5 py-4 lg:hidden" aria-label="Mobile navigation"><div className="mx-auto flex max-w-[1320px] flex-col gap-1">{links.map(([label, href]) => <Link onClick={closeMenu} key={href} href={href} className="rounded-lg px-3 py-3 text-sm text-slate-300 hover:bg-white/[.04]">{label}</Link>)}<div className="mt-2 flex gap-2 border-t border-white/[.08] pt-3"><AccountActions mobile onNavigate={closeMenu}/></div></div></nav>}
  </header>
}
