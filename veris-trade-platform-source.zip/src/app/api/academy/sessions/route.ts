import { getCurrentProfile, jsonError, isValidId } from "@/lib/auth-profile"
import { pool } from "@/lib/db"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

export async function GET() {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to view live classes.", 401)
  try {
    const access = await pool.query(`SELECT 1 FROM "MentorshipSubscription" WHERE "userId" = $1 AND "status" IN ('ACTIVE', 'TRIALING') LIMIT 1`, [profile.id])
    if (!access.rowCount && !["ADMIN", "LECTURER"].includes(profile.role)) return Response.json({ sessions: [], accessRequired: true })
    const result = await pool.query(`SELECT s."id", s."title", s."scheduledAt", s."meetingUrl", c."title" AS "courseTitle", u."username" AS "tutor" FROM "AcademySession" s JOIN "User" u ON u."id" = s."tutorId" LEFT JOIN "Course" c ON c."id" = s."courseId" WHERE s."scheduledAt" > now() ORDER BY s."scheduledAt" ASC LIMIT 50`)
    return Response.json({ sessions: result.rows, accessRequired: false })
  } catch { return jsonError("Live class schedule is temporarily unavailable.", 503) }
}

export async function POST(request: Request) {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to schedule a class.", 401)
  if (!["ADMIN", "LECTURER"].includes(profile.role)) return jsonError("Only approved lecturers can schedule live classes.", 403)
  let body: unknown
  try { body = await request.json() } catch { return jsonError("Request body must be valid JSON.") }
  const value = body as { title?: unknown; scheduledAt?: unknown; meetingUrl?: unknown; courseId?: unknown }
  const title = typeof value.title === "string" ? value.title.trim() : ""
  const scheduledAt = new Date(String(value.scheduledAt ?? ""))
  const meetingUrl = typeof value.meetingUrl === "string" ? value.meetingUrl : ""
  const courseId = typeof value.courseId === "string" ? value.courseId : null
  try {
    const meeting = new URL(meetingUrl)
    if (meeting.protocol !== "https:") return jsonError("Meeting links must use HTTPS.")
  } catch { return jsonError("Provide a valid HTTPS meeting link.") }
  if (!title || title.length > 120 || !Number.isFinite(scheduledAt.getTime()) || scheduledAt.getTime() < Date.now() + 5 * 60_000 || scheduledAt.getTime() > Date.now() + 365 * 24 * 60 * 60_000) return jsonError("Enter a title and a date at least five minutes ahead within the next year.")
  if (courseId && !isValidId(courseId)) return jsonError("Choose a valid course.")
  try {
    const result = await pool.query(`INSERT INTO "AcademySession" ("id", "courseId", "tutorId", "title", "scheduledAt", "meetingUrl") VALUES ($1, $2, $3, $4, $5, $6) RETURNING "id", "title", "scheduledAt", "meetingUrl"`, [crypto.randomUUID(), courseId, profile.id, title, scheduledAt, meetingUrl])
    return Response.json({ session: result.rows[0] }, { status: 201 })
  } catch { return jsonError("Could not schedule the class.", 503) }
}
