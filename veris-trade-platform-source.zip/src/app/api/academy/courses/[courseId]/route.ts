import { getCurrentProfile, isValidId, jsonError } from "@/lib/auth-profile"
import { pool } from "@/lib/db"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

export async function GET(_request: Request, { params }: { params: Promise<{ courseId: string }> }) {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to view course lessons.", 401)
  const { courseId } = await params
  if (!isValidId(courseId)) return jsonError("Choose a valid course.")
  try {
    const course = await pool.query(`SELECT "id", "title", "description", "tutorName" FROM "Course" WHERE "id" = $1`, [courseId])
    if (!course.rowCount) return jsonError("Course not found.", 404)
    const lessons = await pool.query(`SELECT l."id", l."title", l."description", l."contentUrl", l."createdAt", (p."lessonId" IS NOT NULL) AS "completed" FROM "Lesson" l LEFT JOIN "LessonProgress" p ON p."lessonId" = l."id" AND p."userId" = $2 WHERE l."courseId" = $1 AND l."published" = true ORDER BY l."createdAt" ASC`, [courseId, profile.id])
    return Response.json({ course: course.rows[0], lessons: lessons.rows })
  } catch { return jsonError("Course content is temporarily unavailable.", 503) }
}
