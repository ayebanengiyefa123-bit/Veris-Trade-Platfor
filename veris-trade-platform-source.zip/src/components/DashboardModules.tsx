"use client"

import { useState } from "react"
import useSWR from "swr"
import { ArrowDownLeft, ArrowUpRight, BarChart3, Check, CircleAlert, ExternalLink, ShieldCheck, Wallet } from "lucide-react"

type ApiError = { error?: string }
const fetcher = async <T,>(url: string): Promise<T> => {
  const response = await fetch(url, { cache: "no-store" })
  const data = await response.json()
  if (!response.ok) throw new Error((data as ApiError).error || "Could not load data.")
  return data as T
}
const postJson = async <T,>(url: string, body: unknown): Promise<T> => {
  const response = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
  const data = await response.json()
  if (!response.ok) throw new Error(data.error || "Request could not be saved.")
  return data as T
}
const inputClass = "mt-1.5 w-full rounded-lg border border-white/10 bg-[#050a18] px-3 py-2.5 text-sm text-slate-100 outline-none transition placeholder:text-slate-600 focus:border-cyan-300/40"
const buttonClass = "inline-flex items-center justify-center gap-2 rounded-lg bg-cyan-300 px-4 py-2.5 text-xs font-semibold text-slate-950 transition hover:bg-cyan-200 disabled:cursor-not-allowed disabled:opacity-50"

type ProfileData = { profile: { id: string; username: string; role: string; balance: string; tokenBalance: string }; compliance: { countryCode: string; jurisdiction: string; status: string } | null; wallets: Array<{ address: string; provider: string; status: string }>; ledger: Array<{ id: string; entryType: string; amount: string; asset: string; status: string; description: string }> }
type PortfolioData = { requests: Array<{ id: string; requestType: string; asset: string; amount: string; estimatedTokenAmount: string | null; status: string; createdAt: string }>; ledger: ProfileData["ledger"] }

function PortfolioRequests() {
  const { data, error, mutate } = useSWR<PortfolioData>("/api/portfolio/convert", fetcher)
  const [requestType, setRequestType] = useState("deposit")
  const [amount, setAmount] = useState("")
  const [price, setPrice] = useState("")
  const [message, setMessage] = useState("")
  const [busy, setBusy] = useState(false)
  const estimate = Number(amount) > 0 && Number(price) > 0 ? (Number(amount) / Number(price)).toFixed(6) : null

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setMessage("")
    try {
      const result = await postJson<{ notice: string }>("/api/portfolio/convert", { requestType, asset: "USD", amount: Number(amount), indicativeNexPrice: Number(price) })
      setMessage(result.notice); setAmount(""); await mutate()
    } catch (error) { setMessage(error instanceof Error ? error.message : "Could not submit request.") }
    finally { setBusy(false) }
  }

  return <section className="glass rounded-2xl p-5 md:p-6" aria-labelledby="portfolio-actions-title">
    <div className="flex flex-wrap items-start justify-between gap-3"><div><p className="text-[10px] uppercase tracking-[.18em] text-cyan-200">Portfolio controls</p><h2 id="portfolio-actions-title" className="mt-2 text-lg font-semibold">Deposit, withdraw, convert</h2><p className="mt-1 max-w-2xl text-xs leading-5 text-slate-500">Preview an indicative USD-to-NEX estimate and submit a request for review. No funds are moved or credited in this environment.</p></div><Wallet size={18} className="text-cyan-200"/></div>
    <form onSubmit={submit} className="mt-5 grid gap-3 md:grid-cols-4 md:items-end">
      <label className="text-xs text-slate-400">Request type<select className={inputClass} value={requestType} onChange={(event) => setRequestType(event.target.value)}><option value="deposit">Deposit</option><option value="withdraw">Withdraw</option></select></label>
      <label className="text-xs text-slate-400">Amount (USD)<input className={inputClass} type="number" min="0.01" max="1000000" step="0.01" value={amount} onChange={(event) => setAmount(event.target.value)} required/></label>
      <label className="text-xs text-slate-400">Your indicative NEX price<input className={inputClass} type="number" min="0.000001" max="1000000" step="any" value={price} onChange={(event) => setPrice(event.target.value)} placeholder="USD per NEX" required/></label>
      <button className={buttonClass} disabled={busy}>{busy ? "Submitting…" : "Submit request"}<ArrowUpRight size={14}/></button>
    </form>
    <div className="mt-4 flex flex-wrap items-center gap-x-6 gap-y-2 rounded-lg border border-white/[.06] bg-white/[.02] px-4 py-3 text-xs"><span className="text-slate-500">Indicative preview</span><span className="mono text-slate-200">{estimate ? `${estimate} NEX` : "Enter an amount and indicative rate"}</span><span className="text-[10px] text-amber-200/80">Not a market quote or executable order</span></div>
    {message && <p role="status" className="mt-3 text-xs text-cyan-200">{message}</p>}
    {error && <p role="status" className="mt-3 text-xs text-rose-300">{error.message}</p>}
    <div className="mt-6 border-t border-white/[.06] pt-4"><div className="mb-2 flex items-center justify-between"><h3 className="text-xs font-semibold text-slate-300">Recent requests</h3><span className="text-[10px] text-slate-600">Private to your account</span></div>{!data?.requests.length ? <p className="py-3 text-xs text-slate-600">No portfolio requests yet.</p> : data.requests.slice(0, 5).map((item) => <div key={item.id} className="flex flex-wrap items-center justify-between gap-2 border-t border-white/[.04] py-3 text-xs"><span className="text-slate-300">{item.requestType} · ${Number(item.amount).toLocaleString()} {item.asset}</span><span className="text-[10px] text-amber-200">{item.status.replaceAll("_", " ")}</span></div>)}</div>
  </section>
}

function WalletConnection() {
  const { data, mutate } = useSWR<ProfileData>("/api/profile", fetcher)
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState("")

  async function connect() {
    setBusy(true); setMessage("")
    try {
      const provider = window.ethereum
      if (!provider) throw new Error("No EVM wallet extension was found. Open this page in MetaMask or Coinbase Wallet.")
      const accounts = await provider.request({ method: "eth_requestAccounts" }) as string[]
      const address = accounts?.[0]
      if (!address) throw new Error("The wallet did not return an account.")
      const challengeResponse = await fetch(`/api/wallets/link?address=${encodeURIComponent(address)}`, { cache: "no-store" })
      const challenge = await challengeResponse.json()
      if (!challengeResponse.ok) throw new Error(challenge.error || "Could not verify wallet.")
      const signature = await provider.request({ method: "personal_sign", params: [challenge.message, address] })
      const providerName = provider.isMetaMask ? "MetaMask" : provider.isCoinbaseWallet ? "Coinbase Wallet" : "Other EVM"
      const result = await postJson<{ notice: string }>("/api/wallets/link", { address, nonce: challenge.nonce, signature, provider: providerName })
      setMessage(result.notice); await mutate()
    } catch (error) { setMessage(error instanceof Error ? error.message : "Wallet connection was not completed.") }
    finally { setBusy(false) }
  }

  return <section className="glass rounded-2xl p-5" aria-labelledby="wallet-title"><div className="flex items-center gap-3"><span className="grid size-10 place-items-center rounded-xl bg-cyan-300/[.08] text-cyan-200"><Wallet size={18}/></span><div><h2 id="wallet-title" className="text-sm font-semibold">Verified wallets</h2><p className="mt-1 text-[10px] text-slate-500">Ownership verified by a one-time signature</p></div></div>
    <button onClick={connect} disabled={busy} className={`${buttonClass} mt-4 w-full`}>{busy ? "Waiting for wallet…" : "Connect MetaMask / Coinbase"}<ArrowUpRight size={14}/></button>
    <p className="mt-2 text-[10px] leading-4 text-slate-600">Signing proves control only; the signature cannot authorize a transfer.</p>
    {message && <p role="status" className="mt-3 text-xs text-cyan-200">{message}</p>}
    {data?.wallets.map((wallet) => <div key={wallet.address} className="mt-4 rounded-lg border border-white/[.06] px-3 py-2.5"><p className="text-[10px] text-emerald-300">{wallet.provider} · {wallet.status.toLowerCase()}</p><p className="mono mt-1 truncate text-[10px] text-slate-400">{wallet.address}</p></div>)}
  </section>
}

declare global { interface Window { ethereum?: { isMetaMask?: boolean; isCoinbaseWallet?: boolean; request: (args: { method: string; params?: unknown[] }) => Promise<unknown> } } }

function InvestmentRequest() {
  const { data, mutate } = useSWR<{ requests: Array<{ id: string; amount: string; strategy: string; status: string; createdAt: string }> }>("/api/investments/request", fetcher)
  const [amount, setAmount] = useState("")
  const [strategy, setStrategy] = useState("Balanced allocation")
  const [message, setMessage] = useState("")
  const [busy, setBusy] = useState(false)
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setMessage("")
    try { const result = await postJson<{ notice: string }>("/api/investments/request", { amount: Number(amount), strategy }); setMessage(result.notice); setAmount(""); await mutate() }
    catch (error) { setMessage(error instanceof Error ? error.message : "Could not submit request.") }
    finally { setBusy(false) }
  }
  return <section className="glass rounded-2xl p-5" aria-labelledby="allocation-title"><h2 id="allocation-title" className="text-sm font-semibold">Investment allocation request</h2><p className="mt-1 text-xs leading-5 text-slate-500">Choose an intended strategy. Submissions are non-binding and require suitability review.</p><form onSubmit={submit} className="mt-4 grid gap-3"><label className="text-xs text-slate-400">Amount (USD)<input className={inputClass} type="number" min="100" max="1000000" step="0.01" value={amount} onChange={(event) => setAmount(event.target.value)} required/></label><label className="text-xs text-slate-400">Strategy<select className={inputClass} value={strategy} onChange={(event) => setStrategy(event.target.value)}><option>Balanced allocation</option><option>Income focused</option><option>Growth focused</option></select></label><button disabled={busy} className={buttonClass}>{busy ? "Saving…" : "Request allocation"}<ArrowUpRight size={14}/></button></form>{message && <p role="status" className="mt-3 text-xs text-cyan-200">{message}</p>}{data?.requests?.slice(0, 3).map((request) => <div key={request.id} className="mt-3 flex items-center justify-between gap-2 border-t border-white/[.06] pt-3 text-[10px]"><span className="truncate text-slate-400">${Number(request.amount).toLocaleString()} · {request.strategy}</span><span className="text-amber-200">{request.status.replaceAll("_", " ")}</span></div>)}</section>
}

function ComplianceStatus() {
  const { data, mutate } = useSWR<ProfileData>("/api/profile", fetcher)
  const [countryCode, setCountryCode] = useState("")
  const [message, setMessage] = useState("")
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    try { const result = await postJson<{ notice: string }>("/api/compliance/status", { countryCode }); setMessage(result.notice); await mutate() }
    catch (error) { setMessage(error instanceof Error ? error.message : "Could not save jurisdiction.") }
  }
  return <section className="glass rounded-2xl p-5" aria-labelledby="compliance-title"><div className="flex items-center justify-between"><h2 id="compliance-title" className="text-sm font-semibold">Compliance status</h2><ShieldCheck size={17} className="text-cyan-200"/></div><p className="mt-2 text-xs leading-5 text-slate-500">Select your jurisdiction to start a record. Identity checks are not activated until a KYC provider is connected.</p><p className="mt-3 rounded-lg border border-amber-300/10 bg-amber-300/[.04] px-3 py-2 text-[10px] text-amber-100/80">Current state: {data?.compliance?.status?.replaceAll("_", " ") ?? "NOT STARTED"}</p><form onSubmit={submit} className="mt-3 flex gap-2"><label className="sr-only" htmlFor="jurisdiction-code">Country or jurisdiction code</label><input id="jurisdiction-code" className={`${inputClass} mt-0`} maxLength={2} minLength={2} pattern="[A-Za-z]{2}" placeholder="US" value={countryCode} onChange={(event) => setCountryCode(event.target.value.toUpperCase())} required/><button className={buttonClass}>Save</button></form>{message && <p role="status" className="mt-2 text-[10px] text-cyan-200">{message}</p>}</section>
}

function TradingPanels() {
  const { data, error } = useSWR<{ analyses: Array<{ id: string; title: string; setup: string; entryLogic: string; exitLogic: string; riskParams: string; rationale: string; author: string; publishedAt: string }> }>("/api/trade-room", fetcher)
  return <section className="grid gap-5 xl:grid-cols-[1.15fr_.85fr]" aria-label="Trading tools"><div className="glass overflow-hidden rounded-2xl"><div className="flex items-center justify-between border-b border-white/[.06] p-5"><div><p className="text-[10px] uppercase tracking-[.18em] text-cyan-200">TradingView</p><h2 className="mt-1 text-sm font-semibold">Market chart</h2></div><ExternalLink size={15} className="text-slate-500"/></div><iframe title="TradingView NASDAQ composite chart" src="https://s.tradingview.com/widgetembed/?frameElementId=veris-tradingview&symbol=NASDAQ%3AQQQ&interval=D&hidesidetoolbar=1&symboledit=1&saveimage=0&toolbarbg=030612&theme=dark&style=1&timezone=Etc%2FUTC" className="h-[340px] w-full border-0" loading="lazy" allow="clipboard-write; fullscreen" referrerPolicy="no-referrer"/></div><div className="glass rounded-2xl p-5"><div className="flex items-start justify-between gap-3"><div><p className="text-[10px] uppercase tracking-[.18em] text-cyan-200">Trade room</p><h2 className="mt-1 text-sm font-semibold">Latest analyst notes</h2></div><BarChart3 size={17} className="text-cyan-200"/></div><p className="mt-2 text-[10px] leading-4 text-slate-500">Ideas are educational, not investment advice. No orders are executed from this page.</p>{error && <p className="mt-4 text-xs text-rose-300">{error.message}</p>}{!error && !data?.analyses.length && <div className="mt-5 rounded-xl border border-dashed border-white/10 p-4 text-xs leading-5 text-slate-500">No analyst reports have been published yet.</div>}<div className="mt-4 flex flex-col gap-3">{data?.analyses.slice(0, 3).map((item) => <article key={item.id} className="rounded-xl border border-white/[.06] bg-white/[.02] p-4"><div className="flex items-center justify-between gap-3"><h3 className="text-xs font-semibold text-slate-200">{item.title}</h3><span className="shrink-0 text-[9px] text-slate-600">{new Date(item.publishedAt).toLocaleDateString()}</span></div><p className="mt-2 text-[10px] leading-5 text-slate-500"><strong className="text-slate-400">Setup:</strong> {item.setup}</p><p className="mt-2 text-[10px] leading-5 text-slate-500"><strong className="text-slate-400">Risk:</strong> {item.riskParams}</p><p className="mt-2 text-[9px] text-slate-600">By {item.author}</p></article>)}</div></div></section>
}

export function DashboardModules() {
  return <div className="mx-auto max-w-[1320px] px-5 pb-16 md:px-8"><div className="mb-5 grid gap-4 xl:grid-cols-[1.2fr_.8fr]"><PortfolioRequests/><div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-1"><WalletConnection/><InvestmentRequest/></div></div><div className="mb-5 grid gap-4 lg:grid-cols-2"><ComplianceStatus/><section className="glass rounded-2xl p-5"><div className="flex items-center gap-2"><CircleAlert size={16} className="text-amber-200"/><h2 className="text-sm font-semibold">Brokerage connections</h2></div><p className="mt-2 text-xs leading-5 text-slate-500">MetaTrader, Robinhood, and Blockchain.com account connections are not enabled yet. This workspace does not store broker passwords, API keys, or seed phrases.</p><div className="mt-4 grid gap-2 sm:grid-cols-3">{["MetaTrader", "Robinhood", "Blockchain.com"].map((name) => <div key={name} className="rounded-lg border border-white/[.06] px-3 py-2 text-[10px] text-slate-500"><span className="mr-2 inline-block size-1.5 rounded-full bg-amber-300/70"/>{name} · not connected</div>)}</div></section></div><TradingPanels/></div>
}
