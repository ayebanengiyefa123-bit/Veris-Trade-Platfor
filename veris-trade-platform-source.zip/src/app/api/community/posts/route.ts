import { getCurrentProfile, jsonError } from "@/lib/auth-profile"
import { pool } from "@/lib/db"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

export async function GET() {
  try {
    const result = await pool.query(
      `SELECT p."id", p."content", p."likes", p."reposts", p."createdAt", u."username",
        (SELECT count(*)::int FROM "PostComment" c WHERE c."postId" = p."id") AS "commentCount"
       FROM "Post" p JOIN "User" u ON u."id" = p."userId"
       ORDER BY p."createdAt" DESC LIMIT 50`,
    )
    return Response.json({ posts: result.rows })
  } catch {
    return jsonError("Community feed is temporarily unavailable.", 503)
  }
}

export async function POST(request: Request) {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to publish.", 401)
  let body: unknown
  try { body = await request.json() } catch { return jsonError("Request body must be valid JSON.") }
  const content = typeof body === "object" && body !== null && "content" in body && typeof body.content === "string" ? body.content.trim() : ""
  if (content.length < 1 || content.length > 1000) return jsonError("Post must contain between 1 and 1,000 characters.")
  try {
    const id = crypto.randomUUID()
    const result = await pool.query(
      `INSERT INTO "Post" ("id", "content", "userId") VALUES ($1, $2, $3)
       RETURNING "id", "content", "likes", "reposts", "createdAt"`,
      [id, content, profile.id],
    )
    return Response.json({ post: { ...result.rows[0], username: profile.username } }, { status: 201 })
  } catch {
    return jsonError("Could not save post. Please try again.", 503)
  }
}
