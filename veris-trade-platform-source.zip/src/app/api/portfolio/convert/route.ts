import { getCurrentProfile, jsonError } from "@/lib/auth-profile"
import { pool } from "@/lib/db"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"
const allowedAssets = new Set(["USD", "USDC", "BTC", "ETH", "NEX", "VERIS"])

export async function GET() {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to view your portfolio history.", 401)
  try {
    const [requests, ledger] = await Promise.all([
      pool.query(`SELECT "id", "requestType", "asset", "amount"::text, "estimatedTokenAmount"::text, "status", "createdAt" FROM "PortfolioRequest" WHERE "userId" = $1 ORDER BY "createdAt" DESC LIMIT 50`, [profile.id]),
      pool.query(`SELECT "id", "entryType", "amount"::text, "asset", "status", "description", "createdAt" FROM "LedgerEntry" WHERE "userId" = $1 ORDER BY "createdAt" DESC LIMIT 50`, [profile.id]),
    ])
    return Response.json({ requests: requests.rows, ledger: ledger.rows })
  } catch { return jsonError("Portfolio history is temporarily unavailable.", 503) }
}

export async function POST(request: Request) {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to submit a portfolio request.", 401)
  let body: unknown
  try { body = await request.json() } catch { return jsonError("Request body must be valid JSON.") }
  const value = body as { requestType?: unknown; asset?: unknown; amount?: unknown; indicativeNexPrice?: unknown }
  const requestType = value?.requestType
  const asset = value?.asset
  const amount = Number(value?.amount)
  const indicativePrice = Number(value?.indicativeNexPrice)
  if (requestType !== "deposit" && requestType !== "withdraw") return jsonError("Choose deposit or withdrawal.")
  if (typeof asset !== "string" || !allowedAssets.has(asset)) return jsonError("This asset is not supported.")
  if (!Number.isFinite(amount) || amount <= 0 || amount > 1_000_000) return jsonError("Enter an amount between 0 and 1,000,000.")
  if (!Number.isFinite(indicativePrice) || indicativePrice <= 0 || indicativePrice > 1_000_000) return jsonError("Enter a valid indicative NEX price to calculate an estimate.")
  const estimated = asset === "NEX" || asset === "VERIS" ? amount : amount / indicativePrice
  try {
    const result = await pool.query(
      `INSERT INTO "PortfolioRequest" ("id", "userId", "requestType", "asset", "amount", "estimatedTokenAmount", "status")
       VALUES ($1, $2, $3, $4, $5, $6, 'PENDING_REVIEW')
       RETURNING "id", "requestType", "asset", "amount"::text, "estimatedTokenAmount"::text, "status", "createdAt"`,
      [crypto.randomUUID(), profile.id, requestType, asset, amount.toFixed(8), estimated.toFixed(8)],
    )
    return Response.json({ request: result.rows[0], notice: "This is an indicative estimate only. No funds were moved, converted, or credited." }, { status: 201 })
  } catch { return jsonError("Could not save your portfolio request.", 503) }
}
