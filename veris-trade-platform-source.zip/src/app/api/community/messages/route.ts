import { getCurrentProfile, isValidId, jsonError } from "@/lib/auth-profile"
import { pool } from "@/lib/db"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

export async function GET(request: Request) {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to view messages.", 401)
  const params = new URL(request.url).searchParams
  const peerId = params.get("with")
  const groupId = params.get("groupId")
  try {
    if (!peerId && !groupId) {
      const [connections, groups] = await Promise.all([
        pool.query(`SELECT CASE WHEN r."fromUserId" = $1 THEN r."toUserId" ELSE r."fromUserId" END AS "id", u."username" FROM "FriendRequest" r JOIN "User" u ON u."id" = CASE WHEN r."fromUserId" = $1 THEN r."toUserId" ELSE r."fromUserId" END WHERE r."status" = 'ACCEPTED' AND (r."fromUserId" = $1 OR r."toUserId" = $1) ORDER BY u."username"`, [profile.id]),
        pool.query(`SELECT g."id", g."title", gm."status" FROM "GroupMember" gm JOIN "GroupChat" g ON g."id" = gm."groupId" WHERE gm."userId" = $1 ORDER BY g."createdAt" DESC`, [profile.id]),
      ])
      return Response.json({ connections: connections.rows, groups: groups.rows })
    }
    if (isValidId(groupId)) {
      const membership = await pool.query(`SELECT 1 FROM "GroupMember" WHERE "groupId" = $1 AND "userId" = $2 AND "status" = 'ACTIVE'`, [groupId, profile.id])
      if (!membership.rowCount) return jsonError("This private group is unavailable.", 404)
      const result = await pool.query(`SELECT m."id", m."content", m."createdAt", u."username" FROM "DirectMessage" m JOIN "User" u ON u."id" = m."senderId" WHERE m."groupId" = $1 ORDER BY m."createdAt" ASC LIMIT 100`, [groupId])
      return Response.json({ messages: result.rows })
    }
    if (!isValidId(peerId)) return jsonError("Choose a conversation.")
    const friendship = await pool.query(`SELECT 1 FROM "FriendRequest" WHERE "status" = 'ACCEPTED' AND (("fromUserId" = $1 AND "toUserId" = $2) OR ("fromUserId" = $2 AND "toUserId" = $1))`, [profile.id, peerId])
    if (!friendship.rowCount) return jsonError("Private messages are available to accepted connections only.", 403)
    const result = await pool.query(`SELECT m."id", m."content", m."createdAt", m."senderId", u."username" FROM "DirectMessage" m JOIN "User" u ON u."id" = m."senderId" WHERE m."groupId" IS NULL AND ((m."senderId" = $1 AND m."recipientId" = $2) OR (m."senderId" = $2 AND m."recipientId" = $1)) ORDER BY m."createdAt" ASC LIMIT 100`, [profile.id, peerId])
    return Response.json({ messages: result.rows })
  } catch { return jsonError("Messages are temporarily unavailable.", 503) }
}

export async function POST(request: Request) {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to send messages.", 401)
  let body: unknown
  try { body = await request.json() } catch { return jsonError("Request body must be valid JSON.") }
  if (typeof body !== "object" || body === null) return jsonError("Invalid request.")
  const value = body as { action?: unknown; title?: unknown; usernames?: unknown; groupId?: unknown; recipientId?: unknown; content?: unknown }

  if (value.action === "create-group") {
    const title = typeof value.title === "string" ? value.title.trim() : ""
    const usernames = Array.isArray(value.usernames) ? value.usernames.filter((item): item is string => typeof item === "string" && item.length <= 30).slice(0, 19) : []
    if (!title || title.length > 80 || usernames.length === 0) return jsonError("Add a group name and at least one connection.")
    const client = await pool.connect()
    try {
      await client.query("BEGIN")
      const invitees = await client.query(`SELECT "id" FROM "User" WHERE "username" = ANY($1::text[])`, [usernames])
      if (invitees.rowCount !== new Set(usernames).size) { await client.query("ROLLBACK"); return jsonError("One or more members could not be found.") }
      const ids = invitees.rows.map((row) => row.id)
      const accepted = await client.query(`SELECT count(*)::int AS count FROM "FriendRequest" WHERE "status" = 'ACCEPTED' AND (("fromUserId" = $1 AND "toUserId" = ANY($2::text[])) OR ("toUserId" = $1 AND "fromUserId" = ANY($2::text[])))`, [profile.id, ids])
      if (accepted.rows[0].count !== ids.length) { await client.query("ROLLBACK"); return jsonError("Private groups can include accepted connections only.", 403) }
      const groupId = crypto.randomUUID()
      await client.query(`INSERT INTO "GroupChat" ("id", "title") VALUES ($1, $2)`, [groupId, title])
      await client.query(`INSERT INTO "GroupMember" ("groupId", "userId", "status") VALUES ($1, $2, 'ACTIVE')`, [groupId, profile.id])
      for (const inviteeId of ids) await client.query(`INSERT INTO "GroupMember" ("groupId", "userId", "status") VALUES ($1, $2, 'INVITED')`, [groupId, inviteeId])
      await client.query("COMMIT")
      return Response.json({ group: { id: groupId, title, invitedCount: ids.length } }, { status: 201 })
    } catch { await client.query("ROLLBACK"); return jsonError("Could not create this private group.", 503) }
    finally { client.release() }
  }

  if (value.action === "join-group") {
    if (!isValidId(value.groupId)) return jsonError("Choose a valid group.")
    try {
      const joined = await pool.query(`UPDATE "GroupMember" SET "status" = 'ACTIVE' WHERE "groupId" = $1 AND "userId" = $2 AND "status" = 'INVITED' RETURNING "groupId"`, [value.groupId, profile.id])
      if (!joined.rowCount) return jsonError("No invitation was found for this group.", 404)
      return Response.json({ groupId: value.groupId, status: "ACTIVE" })
    } catch { return jsonError("Could not join this group.", 503) }
  }

  const content = typeof value.content === "string" ? value.content.trim() : ""
  if (!content || content.length > 2000) return jsonError("Message must contain between 1 and 2,000 characters.")
  try {
    if (isValidId(value.groupId)) {
      const result = await pool.query(
        `INSERT INTO "DirectMessage" ("id", "senderId", "groupId", "content")
         SELECT $1, $2, g."id", $4 FROM "GroupChat" g JOIN "GroupMember" gm ON gm."groupId" = g."id" AND gm."userId" = $2 AND gm."status" = 'ACTIVE'
         WHERE g."id" = $3 RETURNING "id", "groupId", "content", "createdAt"`, [crypto.randomUUID(), profile.id, value.groupId, content],
      )
      if (!result.rowCount) return jsonError("This private group is unavailable.", 404)
      return Response.json({ message: { ...result.rows[0], username: profile.username } }, { status: 201 })
    }
    if (!isValidId(value.recipientId)) return jsonError("Choose a connection to message.")
    const result = await pool.query(
      `INSERT INTO "DirectMessage" ("id", "senderId", "recipientId", "content")
       SELECT $1, $2, $3, $4 WHERE EXISTS (
         SELECT 1 FROM "FriendRequest" WHERE "status" = 'ACCEPTED' AND (("fromUserId" = $2 AND "toUserId" = $3) OR ("fromUserId" = $3 AND "toUserId" = $2))
       ) RETURNING "id", "content", "createdAt"`, [crypto.randomUUID(), profile.id, value.recipientId, content],
    )
    if (!result.rowCount) return jsonError("Private messages require an accepted connection.", 403)
    return Response.json({ message: { ...result.rows[0], username: profile.username } }, { status: 201 })
  } catch { return jsonError("Could not send your message.", 503) }
}
