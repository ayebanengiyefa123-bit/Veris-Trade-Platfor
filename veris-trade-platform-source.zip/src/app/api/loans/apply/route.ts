import { getCurrentProfile, jsonError } from "@/lib/auth-profile"
import { pool } from "@/lib/db"

export const runtime = "nodejs"

const loanTypes = new Set(["AUTO", "MORTGAGE", "PAYDAY"])

export async function GET() {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to view your applications.", 401)
  try {
    const result = await pool.query(`SELECT "id", "loanType", "loanAmount"::text, "termMonths", "status", "createdAt" FROM "LoanApplication" WHERE "userId" = $1 ORDER BY "createdAt" DESC LIMIT 20`, [profile.id])
    return Response.json({ applications: result.rows })
  } catch { return jsonError("Applications are temporarily unavailable.", 503) }
}

export async function POST(request: Request) {
  const profile = await getCurrentProfile()
  if (!profile) return jsonError("Sign in to submit an application.", 401)
  let body: unknown
  try { body = await request.json() } catch { return jsonError("Request body must be valid JSON.") }
  const value = body as { loanType?: unknown; monthlyIncome?: unknown; monthlyExpenses?: unknown; loanAmount?: unknown; termMonths?: unknown; collateral?: unknown }
  const type = String(value?.loanType ?? "")
  const income = Number(value?.monthlyIncome)
  const expenses = Number(value?.monthlyExpenses)
  const loanAmount = Number(value?.loanAmount)
  const termMonths = Number(value?.termMonths)
  const collateral = typeof value?.collateral === "string" ? value.collateral.trim().slice(0, 300) : null
  if (!loanTypes.has(type)) return jsonError("Choose a supported loan type.")
  if (![income, expenses, loanAmount].every(Number.isFinite) || income < 0 || income > 10_000_000 || expenses < 0 || expenses > 10_000_000 || loanAmount <= 0 || loanAmount > 10_000_000) return jsonError("Enter valid monthly finances and a requested amount.")
  if (!Number.isInteger(termMonths) || termMonths < 1 || termMonths > 480) return jsonError("Choose a valid loan term.")
  if (expenses > income * 5) return jsonError("Monthly expenses exceed the supported assessment range.")
  try {
    const result = await pool.query(`INSERT INTO "LoanApplication" ("id", "userId", "loanType", "monthlyIncome", "monthlyExpenses", "loanAmount", "termMonths", "collateral") VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING "id", "loanType", "status", "createdAt"`, [crypto.randomUUID(), profile.id, type, income.toFixed(2), expenses.toFixed(2), loanAmount.toFixed(2), termMonths, collateral])
    return Response.json({ application: result.rows[0], notice: "Application received for review. This is not a credit decision or loan offer." }, { status: 201 })
  } catch { return jsonError("Could not submit your application.", 503) }
}
