import { PlatformPage } from "@/components/PlatformPage"
export default function HomePage() { return <PlatformPage view="home"/> }
