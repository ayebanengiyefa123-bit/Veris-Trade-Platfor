"use client"

import { useState } from "react"
import useSWR from "swr"
import { ArrowUpRight, CarFront, House, Wallet } from "lucide-react"

const types = [
  { value: "AUTO", label: "Auto financing", description: "Request a review for vehicle financing.", icon: CarFront },
  { value: "MORTGAGE", label: "Mortgage access", description: "Request a review for real-estate financing.", icon: House },
  { value: "PAYDAY", label: "Payday lending", description: "Request a short-term credit assessment.", icon: Wallet },
]
const inputClass = "mt-1.5 w-full rounded-lg border border-white/10 bg-[#050a18] px-3 py-2.5 text-sm text-slate-100 outline-none focus:border-cyan-300/40"

export function LoansHub() {
  const { data, mutate } = useSWR<{ applications: Array<{ id: string; loanType: string; loanAmount: string; termMonths: number; status: string; createdAt: string }> }>("/api/loans/apply", async (url: string) => { const response = await fetch(url, { cache: "no-store" }); const result = await response.json(); if (!response.ok) throw new Error(result.error || "Could not load applications."); return result })
  const [loanType, setLoanType] = useState("AUTO")
  const [monthlyIncome, setMonthlyIncome] = useState("")
  const [monthlyExpenses, setMonthlyExpenses] = useState("")
  const [loanAmount, setLoanAmount] = useState("")
  const [termMonths, setTermMonths] = useState("36")
  const [collateral, setCollateral] = useState("")
  const [message, setMessage] = useState("")
  const [busy, setBusy] = useState(false)

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setMessage("")
    try {
      const response = await fetch("/api/loans/apply", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ loanType, monthlyIncome: Number(monthlyIncome), monthlyExpenses: Number(monthlyExpenses), loanAmount: Number(loanAmount), termMonths: Number(termMonths), collateral }) })
      const data = await response.json()
      if (!response.ok) throw new Error(data.error || "Could not submit application.")
      setMessage(`Application ${data.application.id.slice(0, 8)} received. ${data.notice}`)
      await mutate()
    } catch (error) { setMessage(error instanceof Error ? error.message : "Could not submit application.") }
    finally { setBusy(false) }
  }

  return <div className="mx-auto max-w-[1320px] px-5 py-10 pb-16 md:px-8"><header className="mb-8 max-w-3xl"><p className="text-[10px] uppercase tracking-[.2em] text-cyan-200">Veris credit access</p><h1 className="mt-3 text-4xl font-medium tracking-tight">Financing with a clearer picture.</h1><p className="mt-4 text-sm leading-6 text-slate-400">Request an initial review for auto financing, mortgages, or short-term credit. Applications are private to your account and are not lending offers or credit decisions.</p></header>
    <div className="grid gap-5 lg:grid-cols-[.8fr_1.2fr]"><section className="flex flex-col gap-3" aria-label="Available loan categories">{types.map(({ value, label, description, icon: Icon }) => <button key={value} type="button" onClick={() => setLoanType(value)} className={`glass rounded-xl p-5 text-left transition ${loanType === value ? "border-cyan-300/30" : "hover:border-white/20"}`} aria-pressed={loanType === value}><div className="flex items-center gap-3"><span className="grid size-10 place-items-center rounded-xl bg-cyan-300/[.08] text-cyan-200"><Icon size={19}/></span><span><strong className="block text-sm font-semibold">{label}</strong><span className="mt-1 block text-xs text-slate-500">{description}</span></span></div></button>)}<div className="glass rounded-xl p-5"><p className="text-xs font-semibold text-slate-300">Before applying</p><ul className="mt-3 flex flex-col gap-2 text-[11px] leading-5 text-slate-500"><li>Only financial information needed for an initial assessment is requested.</li><li>Do not enter account passwords, payment card numbers, or government ID numbers.</li><li>Loan terms, eligibility, and APR depend on a licensed lender and your jurisdiction.</li></ul></div></section>
      <section className="glass rounded-2xl p-5 md:p-7"><h2 className="text-lg font-semibold">Start a {types.find((item) => item.value === loanType)?.label.toLowerCase()} review</h2><p className="mt-1 text-xs text-slate-500">Financial details are sent to the Veris application database over the authenticated server API.</p><form onSubmit={submit} className="mt-5 grid gap-4 sm:grid-cols-2"><label className="text-xs text-slate-400">Monthly income (USD)<input className={inputClass} type="number" min="0" max="10000000" step="0.01" value={monthlyIncome} onChange={(event) => setMonthlyIncome(event.target.value)} required/></label><label className="text-xs text-slate-400">Monthly expenses (USD)<input className={inputClass} type="number" min="0" max="10000000" step="0.01" value={monthlyExpenses} onChange={(event) => setMonthlyExpenses(event.target.value)} required/></label><label className="text-xs text-slate-400">Requested amount (USD)<input className={inputClass} type="number" min="0.01" max="10000000" step="0.01" value={loanAmount} onChange={(event) => setLoanAmount(event.target.value)} required/></label><label className="text-xs text-slate-400">Preferred term<select className={inputClass} value={termMonths} onChange={(event) => setTermMonths(event.target.value)}>{[6, 12, 24, 36, 60, 120, 240, 360].map((months) => <option key={months} value={months}>{months} months</option>)}</select></label><label className="text-xs text-slate-400 sm:col-span-2">Collateral or asset context <span className="text-slate-600">(optional, no account details)</span><textarea className={`${inputClass} resize-y`} rows={3} maxLength={300} value={collateral} onChange={(event) => setCollateral(event.target.value)} placeholder="Describe the asset type or context without entering sensitive identifiers."/></label><div className="sm:col-span-2"><button disabled={busy} className="inline-flex items-center gap-2 rounded-lg bg-cyan-300 px-5 py-3 text-xs font-semibold text-slate-950 hover:bg-cyan-200 disabled:opacity-50">{busy ? "Submitting…" : "Submit for review"}<ArrowUpRight size={14}/></button>{message && <p role="status" className="mt-3 text-xs leading-5 text-cyan-200">{message}</p>}{data?.applications?.length ? <div className="mt-5 border-t border-white/[.06] pt-4"><h3 className="text-xs font-semibold text-slate-300">Your recent applications</h3>{data.applications.slice(0, 5).map((application) => <div key={application.id} className="flex flex-wrap items-center justify-between gap-2 border-t border-white/[.04] py-3 text-[10px]"><span className="text-slate-400">{application.loanType} · ${Number(application.loanAmount).toLocaleString()} · {application.termMonths} months</span><span className="text-amber-200">{application.status.replaceAll("_", " ")}</span></div>)}</div> : null}</div></form></section>
    </div>
  </div>
}
