import type { Metadata } from "next"
import { PlatformPage } from "@/components/PlatformPage"
export const metadata: Metadata = { title: "Community" }
export default function CommunityPage() { return <PlatformPage view="community"/> }
