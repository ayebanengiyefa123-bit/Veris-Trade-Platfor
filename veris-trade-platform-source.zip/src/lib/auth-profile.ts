import "server-only"
import { auth, currentUser } from "@clerk/nextjs/server"
import { pool } from "@/lib/db"

export type Profile = {
  id: string
  username: string
  email: string | null
  role: string
  balance: string
  tokenBalance: string
}

export async function getCurrentProfile(): Promise<Profile | null> {
  const { userId } = await auth()
  if (!userId) return null

  const clerkUser = await currentUser()
  const email = clerkUser?.emailAddresses[0]?.emailAddress ?? null
  const sourceName = clerkUser?.username || clerkUser?.firstName || email?.split("@")[0] || "member"
  const base = sourceName.toLowerCase().replace(/[^a-z0-9_]/g, "").slice(0, 20) || "member"
  const username = `${base}_${userId.slice(-6).toLowerCase()}`
  const result = await pool.query<Profile>(
    `INSERT INTO "User" ("id", "clerkId", "username", "email")
     VALUES ($1, $1, $2, $3)
     ON CONFLICT ("clerkId") DO UPDATE SET "email" = EXCLUDED."email"
     RETURNING "id", "username", "email", "role", "balance"::text, "tokenBalance"::text`,
    [userId, username, email],
  )
  return result.rows[0] ?? null
}

export function jsonError(message: string, status = 400) {
  return Response.json({ error: message }, { status })
}

export function isValidId(value: unknown): value is string {
  return typeof value === "string" && value.length > 0 && value.length <= 128
}
